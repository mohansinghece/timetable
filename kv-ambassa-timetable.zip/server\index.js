// Backend for KV Ambassa Timetable.
// Stores the whole app state as a single shared document so that any teacher
// can view the timetable/arrangement (read-only) without logging in, while
// only the admin (password) can save changes. Also serves the built SPA.
import express from 'express'
import cors from 'cors'
import { Low } from 'lowdb'
import { JSONFile } from 'lowdb/node'
import { fileURLToPath } from 'url'
import path from 'path'
import fs from 'fs'
import os from 'os'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PORT = process.env.PORT || 4000

process.on('uncaughtException', (err) => console.error('uncaughtException:', err))
process.on('unhandledRejection', (err) => console.error('unhandledRejection:', err))

// state: the full AppState (or null until first save). password: admin password.
const defaultData = { state: null, password: 'admin123' }

function resolveDbFile() {
  const candidates = [
    process.env.DB_FILE,
    path.join(__dirname, 'db.json'),
    path.join(os.tmpdir(), 'kv-timetable-db.json'),
  ].filter(Boolean)
  for (const file of candidates) {
    try {
      fs.accessSync(path.dirname(file), fs.constants.W_OK)
      return file
    } catch {
      /* try next */
    }
  }
  return path.join(os.tmpdir(), 'kv-timetable-db.json')
}

const db = new Low(new JSONFile(resolveDbFile()), defaultData)

async function initDb() {
  await db.read()
  db.data ||= structuredClone(defaultData)
  if (typeof db.data.password !== 'string') db.data.password = 'admin123'
  if (db.data.state === undefined) db.data.state = null
  await db.write().catch((e) => console.error('db write failed:', e))
}

const app = express()
app.use(cors())
app.use(express.json({ limit: '8mb' }))

function checkAdmin(req, res, next) {
  const token = req.headers['x-admin-token']
  if (token && String(token) === String(db.data.password)) return next()
  return res.status(401).json({ error: 'Unauthorized' })
}

app.get('/api/health', (req, res) => res.json({ ok: true }))

// Public: read the current shared state.
app.get('/api/state', (req, res) => {
  res.json({ state: db.data.state })
})

// Admin: login (validate password).
app.post('/api/login', (req, res) => {
  const { password } = req.body || {}
  if (String(password || '') === String(db.data.password)) {
    return res.json({ ok: true, token: db.data.password })
  }
  res.status(401).json({ error: 'Invalid password' })
})

// Admin: save the whole state. Keeps the server password in sync with
// settings.adminPassword so the admin can change it from the UI.
app.put('/api/state', checkAdmin, async (req, res) => {
  const { state } = req.body || {}
  if (!state || typeof state !== 'object') {
    return res.status(400).json({ error: 'Invalid state' })
  }
  db.data.state = state
  const newPw = state?.settings?.adminPassword
  if (typeof newPw === 'string' && newPw.trim()) db.data.password = newPw.trim()
  try {
    await db.write()
  } catch (e) {
    console.error('db write failed:', e)
    return res.status(500).json({ error: 'Save failed' })
  }
  res.json({ ok: true })
})

// ---------- Serve built client ----------
const distDir = path.join(__dirname, '..', 'dist')
const indexHtml = path.join(distDir, 'index.html')
app.use(
  express.static(distDir, {
    setHeaders: (res, filePath) => {
      if (filePath.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache')
    },
  }),
)
app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) return res.status(404).json({ error: 'Not found' })
  if (fs.existsSync(indexHtml)) return res.sendFile(indexHtml)
  res
    .status(200)
    .send(
      '<!doctype html><html><body style="font-family:sans-serif;padding:40px">' +
        '<h1>KV Ambassa Timetable</h1><p>Frontend build (<code>dist</code>) not found. ' +
        'Run <code>npm run build</code>.</p></body></html>',
    )
})

initDb()
  .catch((e) => console.error('initDb failed (continuing):', e))
  .finally(() => {
    app.listen(PORT, () => console.log(`KV Ambassa Timetable running on ${PORT}`))
  })

export default app
