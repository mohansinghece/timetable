import { useState } from 'react'
import { useApp } from '../../store/AppContext'
import { Card, Empty, Modal, PageHeader } from '../../components/ui'
import { GRADES, STAGE_LABELS, STAGE_TEMPLATES, stageForGrade } from '../../lib/seed'
import { SchoolClass } from '../../types'
import { className } from '../../lib/timetable'

export default function Classes() {
  const { state, update } = useApp()
  const [open, setOpen] = useState(false)
  const [grade, setGrade] = useState('I')
  const [section, setSection] = useState('A')

  const add = () => {
    const id = `c_${grade}_${section}`.replace(/\s+/g, '')
    if (state.classes.some((c) => c.id === id)) {
      alert('That class & section already exists.')
      return
    }
    const stage = stageForGrade(grade)
    update((d) => {
      d.classes.push({ id, grade, section: section.toUpperCase(), stage })
      d.classSubjects.push({
        classId: id,
        items: STAGE_TEMPLATES[stage].map((t) => ({
          subjectId: t.subjectId,
          periodsPerWeek: t.periodsPerWeek,
          block: !!t.block,
          main: !!t.main,
          lockTeacher: !!t.main,
        })),
      })
    })
    setOpen(false)
  }

  const remove = (c: SchoolClass) => {
    if (!confirm(`Delete class ${className(c)} and its timetable?`)) return
    update((d) => {
      d.classes = d.classes.filter((x) => x.id !== c.id)
      d.classSubjects = d.classSubjects.filter((x) => x.classId !== c.id)
      d.timetables = d.timetables.filter((x) => x.classId !== c.id)
    })
  }

  // group by stage
  const grouped = (['foundational', 'preparatory', 'middle', 'secondary'] as const).map((st) => ({
    stage: st,
    classes: state.classes.filter((c) => c.stage === st),
  }))

  return (
    <div>
      <PageHeader
        title="Classes & Sections"
        right={
          <button onClick={() => setOpen(true)} className="btn-primary text-xs">
            + Add
          </button>
        }
      />
      {state.classes.length === 0 ? (
        <Empty icon="🏫" text="No classes yet." />
      ) : (
        <div className="space-y-4">
          {grouped.map(
            (g) =>
              g.classes.length > 0 && (
                <div key={g.stage}>
                  <p className="label px-1">{STAGE_LABELS[g.stage]}</p>
                  <div className="grid grid-cols-2 gap-2">
                    {g.classes.map((c) => (
                      <Card key={c.id} className="flex items-center justify-between">
                        <span className="font-bold text-slate-800">{className(c)}</span>
                        <button onClick={() => remove(c)} className="text-red-400 px-1">🗑️</button>
                      </Card>
                    ))}
                  </div>
                </div>
              ),
          )}
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Add Class"
        icon="🏫"
        footer={
          <button onClick={add} className="btn-primary w-full">
            Add Class
          </button>
        }
      >
        <div className="space-y-3">
          <div>
            <label className="label">Grade</label>
            <div className="grid grid-cols-6 gap-2">
              {GRADES.map((g) => (
                <button
                  key={g}
                  onClick={() => setGrade(g)}
                  className={`rounded-xl py-2 text-sm font-bold border ${
                    grade === g
                      ? 'bg-brand-700 text-white border-brand-700'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="label">Section</label>
            <input
              className="input uppercase"
              value={section}
              maxLength={2}
              onChange={(e) => setSection(e.target.value)}
              placeholder="A"
            />
          </div>
          <p className="text-xs text-slate-500">
            Stage: <b>{STAGE_LABELS[stageForGrade(grade)]}</b>. Default subject periods for this
            stage will be applied automatically (editable later).
          </p>
        </div>
      </Modal>
    </div>
  )
}
