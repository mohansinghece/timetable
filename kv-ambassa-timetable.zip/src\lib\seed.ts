import {
  AppState,
  BreakDef,
  PeriodTiming,
  Post,
  SchoolClass,
  Settings,
  Stage,
  Subject,
} from '../types'

export const uid = () => Math.random().toString(36).slice(2, 10)

// ---- Default posts ----
const POSTS: Post[] = [
  { id: 'prt', name: 'Primary Teacher', code: 'PRT' },
  { id: 'tgt', name: 'Trained Graduate Teacher', code: 'TGT' },
  { id: 'pgt', name: 'Post Graduate Teacher', code: 'PGT' },
  { id: 'librarian', name: 'Librarian', code: 'LIB' },
  { id: 'computer', name: 'Computer Instructor', code: 'CI' },
  { id: 'nurse', name: 'Nurse', code: 'NUR' },
  { id: 'spledu', name: 'Special Educator (PRT)', code: 'SE' },
  { id: 'music', name: 'PRT (Music)', code: 'MUS' },
]

// ---- Default subjects with acronyms ----
const SUBJECTS: Subject[] = [
  { id: 's_hin', name: 'Hindi (R1)', acronym: 'HIN' },
  { id: 's_eng', name: 'English (R2)', acronym: 'ENG' },
  { id: 's_math', name: 'Mathematics', acronym: 'MATHS' },
  { id: 's_gard', name: 'Gardening', acronym: 'GARD' },
  { id: 's_va', name: 'Visual Arts', acronym: 'VA' },
  { id: 's_pa', name: 'Performing Arts', acronym: 'PA' },
  { id: 's_pe', name: 'Physical Education (PE)', acronym: 'PE' },
  { id: 's_lib', name: 'Library', acronym: 'LIB' },
  { id: 's_cla', name: 'Creative Learning Activities (CLA)', acronym: 'CLA' },
  { id: 's_ct', name: 'Computational Thinking (CT)', acronym: 'CT' },
  { id: 's_twau', name: 'The World Around Us (TWAU)', acronym: 'TWAU' },
  { id: 's_gs', name: 'Games & Sports', acronym: 'GS' },
  { id: 's_yoga', name: 'Yoga', acronym: 'YOGA' },
  { id: 's_dl', name: 'Digital Literacy (DL)', acronym: 'DL' },
  { id: 's_sans', name: 'Sanskrit (R3)', acronym: 'SANS' },
  { id: 's_sci', name: 'Science', acronym: 'SCI' },
  { id: 's_sst', name: 'Social Science', acronym: 'SST' },
  { id: 's_ve', name: 'Vocational Education (VE)', acronym: 'VE' },
  { id: 's_ai', name: 'Artificial Intelligence (AI)', acronym: 'AI' },
  { id: 's_complit', name: 'Computer Literacy', acronym: 'CL' },
  { id: 's_ida', name: 'Inter Disciplinary Area (IDA)', acronym: 'IDA' },
  { id: 's_eco', name: 'Economics', acronym: 'ECO' },
  { id: 's_com', name: 'Commerce', acronym: 'COM' },
]

// ---- Stage period templates (subjectId -> periods/week, block flag) ----
type TemplateItem = { subjectId: string; periodsPerWeek: number; block?: boolean; main?: boolean }

export const STAGE_TEMPLATES: Record<Stage, TemplateItem[]> = {
  foundational: [
    { subjectId: 's_hin', periodsPerWeek: 10, block: true, main: true },
    { subjectId: 's_eng', periodsPerWeek: 10, block: true, main: true },
    { subjectId: 's_math', periodsPerWeek: 10, block: true, main: true },
    { subjectId: 's_gard', periodsPerWeek: 4 },
    { subjectId: 's_va', periodsPerWeek: 4 },
    { subjectId: 's_pa', periodsPerWeek: 2 },
    { subjectId: 's_pe', periodsPerWeek: 4 },
    { subjectId: 's_lib', periodsPerWeek: 2 },
    { subjectId: 's_cla', periodsPerWeek: 2 },
  ],
  preparatory: [
    { subjectId: 's_hin', periodsPerWeek: 7, main: true, block: true },
    { subjectId: 's_eng', periodsPerWeek: 7, main: true, block: true },
    { subjectId: 's_math', periodsPerWeek: 8, main: true, block: true },
    { subjectId: 's_ct', periodsPerWeek: 2 },
    { subjectId: 's_twau', periodsPerWeek: 8, block: true },
    { subjectId: 's_va', periodsPerWeek: 3 },
    { subjectId: 's_pa', periodsPerWeek: 2 },
    { subjectId: 's_gs', periodsPerWeek: 3 },
    { subjectId: 's_yoga', periodsPerWeek: 2 },
    { subjectId: 's_lib', periodsPerWeek: 2 },
    { subjectId: 's_dl', periodsPerWeek: 2 },
    { subjectId: 's_cla', periodsPerWeek: 2 },
  ],
  middle: [
    { subjectId: 's_hin', periodsPerWeek: 5 },
    { subjectId: 's_eng', periodsPerWeek: 5 },
    { subjectId: 's_sans', periodsPerWeek: 3 },
    { subjectId: 's_math', periodsPerWeek: 5 },
    { subjectId: 's_ct', periodsPerWeek: 2 },
    { subjectId: 's_sci', periodsPerWeek: 6 },
    { subjectId: 's_sst', periodsPerWeek: 6 },
    { subjectId: 's_va', periodsPerWeek: 2 },
    { subjectId: 's_pa', periodsPerWeek: 1 },
    { subjectId: 's_gs', periodsPerWeek: 2 },
    { subjectId: 's_yoga', periodsPerWeek: 1 },
    { subjectId: 's_ve', periodsPerWeek: 4 },
    { subjectId: 's_lib', periodsPerWeek: 2 },
    { subjectId: 's_ai', periodsPerWeek: 1 },
    { subjectId: 's_complit', periodsPerWeek: 1 },
    { subjectId: 's_cla', periodsPerWeek: 2 },
  ],
  secondary: [
    { subjectId: 's_hin', periodsPerWeek: 5 },
    { subjectId: 's_eng', periodsPerWeek: 5 },
    { subjectId: 's_sans', periodsPerWeek: 3 },
    { subjectId: 's_math', periodsPerWeek: 7, block: true },
    { subjectId: 's_sci', periodsPerWeek: 7, block: true },
    { subjectId: 's_sst', periodsPerWeek: 5 },
    { subjectId: 's_ida', periodsPerWeek: 2 },
    { subjectId: 's_va', periodsPerWeek: 2 },
    { subjectId: 's_pa', periodsPerWeek: 1 },
    { subjectId: 's_gs', periodsPerWeek: 2 },
    { subjectId: 's_yoga', periodsPerWeek: 1 },
    { subjectId: 's_ve', periodsPerWeek: 4 },
    { subjectId: 's_dl', periodsPerWeek: 2 },
    { subjectId: 's_cla', periodsPerWeek: 2 },
  ],
}

export const GRADES = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII']

export function stageForGrade(grade: string): Stage {
  const idx = GRADES.indexOf(grade)
  if (idx <= 1) return 'foundational'
  if (idx <= 4) return 'preparatory'
  if (idx <= 7) return 'middle'
  return 'secondary'
}

export const STAGE_LABELS: Record<Stage, string> = {
  foundational: 'Foundational (I–II)',
  preparatory: 'Preparatory (III–V)',
  middle: 'Middle (VI–VIII)',
  secondary: 'Secondary (IX–XII)',
}

function defaultClasses(): SchoolClass[] {
  // Section A for every grade by default.
  return GRADES.map((grade) => ({
    id: `c_${grade}_A`,
    grade,
    section: 'A',
    stage: stageForGrade(grade),
  }))
}

function defaultTimings(): PeriodTiming[] {
  return buildTimings('09:00', 8, 40, [{ afterPeriod: 4, minutes: 30, label: 'Recess' }])
}

/** Effective breaks for settings (falls back to the single recess for old data). */
export function getBreaks(s: Settings): BreakDef[] {
  if (s.breaks && s.breaks.length) return s.breaks
  return [{ afterPeriod: s.recessAfterPeriod, minutes: s.recessMinutes, label: 'Recess' }]
}

export function buildTimings(
  start: string,
  periods: number,
  periodMin: number,
  breaks: BreakDef[],
): PeriodTiming[] {
  const toMin = (t: string) => {
    const [h, m] = t.split(':').map(Number)
    return h * 60 + m
  }
  const toStr = (m: number) =>
    `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`

  const byAfter = new Map<number, BreakDef>()
  for (const b of breaks) byAfter.set(b.afterPeriod, b)

  const out: PeriodTiming[] = []
  let cur = toMin(start)
  for (let i = 1; i <= periods; i++) {
    const end = cur + periodMin
    const brk = byAfter.get(i)
    out.push({
      start: toStr(cur),
      end: toStr(end),
      isBreak: !!brk,
      breakAfter: brk ? { label: brk.label, minutes: brk.minutes, end: toStr(end + brk.minutes) } : undefined,
    })
    cur = end + (brk ? brk.minutes : 0)
  }
  return out
}

const DEFAULT_SETTINGS: Settings = {
  schoolName: 'Kendriya Vidyalaya Ambassa, Dhalai',
  periodsPerDay: 8,
  periodMinutes: 40,
  recessMinutes: 30,
  recessAfterPeriod: 4,
  dayStart: '09:00',
  adminPassword: 'admin123',
  breaks: [{ afterPeriod: 4, minutes: 30, label: 'Recess' }],
}

export function seedState(): AppState {
  const classes = defaultClasses()
  return {
    settings: DEFAULT_SETTINGS,
    posts: POSTS,
    subjects: SUBJECTS,
    teachers: [],
    classes,
    classSubjects: classes.map((c) => ({
      classId: c.id,
      items: STAGE_TEMPLATES[c.stage].map((t) => ({
        subjectId: t.subjectId,
        periodsPerWeek: t.periodsPerWeek,
        block: !!t.block,
        main: !!t.main,
        lockTeacher: !!t.main,
      })),
    })),
    timings: defaultTimings(),
    timetables: [],
    arrangements: [],
    commonBusy: {},
  }
}
