import { useState } from 'react'
import { useApp } from '../../store/AppContext'
import { Card, Empty, Modal, PageHeader } from '../../components/ui'
import { uid } from '../../lib/seed'
import { subjectColor } from '../../lib/timetable'
import { Subject } from '../../types'

const PALETTE = [
  '#ffffff', '#fca5a5', '#93c5fd', '#86efac', '#fdba74', '#c4b5fd', '#5eead4', '#f0abfc', '#fcd34d',
  '#67e8f9', '#a5b4fc', '#6ee7b7', '#fda4af', '#bef264', '#7dd3fc', '#f9a8d4', '#fde047',
  '#cbd5e1',
]

export default function Subjects() {
  const { state, update } = useApp()
  const [open, setOpen] = useState(false)
  const [edit, setEdit] = useState<Subject | null>(null)
  const [name, setName] = useState('')
  const [acr, setAcr] = useState('')
  const [color, setColor] = useState('')

  const start = (s?: Subject) => {
    setEdit(s ?? null)
    setName(s?.name ?? '')
    setAcr(s?.acronym ?? '')
    setColor(s?.color ?? '')
    setOpen(true)
  }

  const save = () => {
    if (!name.trim() || !acr.trim()) return
    update((d) => {
      if (edit) {
        const t = d.subjects.find((x) => x.id === edit.id)
        if (t) {
          t.name = name.trim()
          t.acronym = acr.trim().toUpperCase()
          t.color = color || undefined
        }
      } else {
        d.subjects.push({
          id: uid(),
          name: name.trim(),
          acronym: acr.trim().toUpperCase(),
          color: color || undefined,
        })
      }
    })
    setOpen(false)
  }

  const remove = (s: Subject) => {
    const usedByClass = state.classSubjects.some((c) => c.items.some((i) => i.subjectId === s.id))
    if (usedByClass) {
      alert('This subject is used in a class configuration. Remove it there first.')
      return
    }
    if (!confirm(`Delete subject "${s.name}"?`)) return
    update((d) => {
      d.subjects = d.subjects.filter((x) => x.id !== s.id)
    })
  }

  return (
    <div>
      <PageHeader
        title="Subjects"
        right={
          <button onClick={() => start()} className="btn-primary text-xs">
            + Add
          </button>
        }
      />
      {state.subjects.length === 0 ? (
        <Empty icon="📖" text="No subjects yet." />
      ) : (
        <div className="grid grid-cols-1 gap-2">
          {state.subjects.map((s) => (
            <Card key={s.id} className="flex items-center gap-3">
              <span
                className="h-7 w-7 rounded-lg shrink-0 border border-black/5"
                style={{ background: subjectColor(state, s.id) }}
              />
              <span className="chip bg-indigo-50 text-indigo-700 min-w-[3.5rem] justify-center">
                {s.acronym}
              </span>
              <span className="grow font-semibold text-slate-800 text-sm">{s.name}</span>
              <button onClick={() => start(s)} className="text-slate-400 px-2">✏️</button>
              <button onClick={() => remove(s)} className="text-red-400 px-2">🗑️</button>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={edit ? 'Edit Subject' : 'Add Subject'}
        icon="📖"
        footer={
          <button onClick={save} className="btn-primary w-full">
            Save
          </button>
        }
      >
        <div className="space-y-3">
          <div>
            <label className="label">Subject name</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Social Science" />
          </div>
          <div>
            <label className="label">Acronym (shown in timetable cells)</label>
            <input className="input uppercase" value={acr} onChange={(e) => setAcr(e.target.value)} placeholder="e.g. SST" />
          </div>
          <div>
            <label className="label">Cell colour</label>
            <div className="flex flex-wrap gap-2">
              {PALETTE.map((c) => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={`h-8 w-8 rounded-lg border-2 ${color === c ? 'border-slate-800' : 'border-slate-200'}`}
                  style={{ background: c }}
                />
              ))}
              <button
                onClick={() => setColor('')}
                className={`h-8 px-2 rounded-lg border text-[11px] font-semibold ${
                  color === '' ? 'border-slate-800 text-slate-800' : 'border-slate-200 text-slate-400'
                }`}
              >
                Auto
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  )
}
