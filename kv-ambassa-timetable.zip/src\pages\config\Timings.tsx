import { useApp } from '../../store/AppContext'
import { Card, PageHeader } from '../../components/ui'
import { buildTimings, getBreaks } from '../../lib/seed'
import { BreakDef, Settings } from '../../types'

export default function Timings() {
  const { state, update } = useApp()
  const s = state.settings
  const breaks = getBreaks(s)

  const regen = (patch: Partial<Settings>, newBreaks?: BreakDef[]) =>
    update((d) => {
      Object.assign(d.settings, patch)
      if (newBreaks) d.settings.breaks = newBreaks
      const bks = d.settings.breaks && d.settings.breaks.length ? d.settings.breaks : getBreaks(d.settings)
      d.timings = buildTimings(d.settings.dayStart, d.settings.periodsPerDay, d.settings.periodMinutes, bks)
    })

  const setBreaks = (next: BreakDef[]) => regen({}, next)

  const addBreak = () =>
    setBreaks([
      ...breaks,
      { afterPeriod: Math.min(4, s.periodsPerDay), minutes: 15, label: 'Break' },
    ])
  const updBreak = (i: number, patch: Partial<BreakDef>) =>
    setBreaks(breaks.map((b, idx) => (idx === i ? { ...b, ...patch } : b)))
  const delBreak = (i: number) => setBreaks(breaks.filter((_, idx) => idx !== i))

  const setTiming = (i: number, key: 'start' | 'end', val: string) =>
    update((d) => {
      if (d.timings[i]) d.timings[i][key] = val
    })

  return (
    <div>
      <PageHeader title="Period Timings & Breaks" />
      <Card className="space-y-3 mb-3">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Day start</label>
            <input type="time" className="input" value={s.dayStart} onChange={(e) => regen({ dayStart: e.target.value })} />
          </div>
          <div>
            <label className="label">Periods / day</label>
            <input
              type="number"
              className="input"
              value={s.periodsPerDay}
              min={1}
              max={12}
              onChange={(e) => regen({ periodsPerDay: Math.max(1, +e.target.value || 1) })}
            />
          </div>
          <div className="col-span-2">
            <label className="label">Period length (min)</label>
            <input
              type="number"
              className="input"
              value={s.periodMinutes}
              onChange={(e) => regen({ periodMinutes: +e.target.value || 40 })}
            />
          </div>
        </div>
      </Card>

      <Card className="mb-3">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-bold text-slate-800">Breaks / Recess</h2>
          <button onClick={addBreak} className="btn-soft text-xs">+ Add break</button>
        </div>
        {breaks.length === 0 && <p className="text-sm text-slate-400">No breaks. Add one above.</p>}
        <div className="space-y-2">
          {breaks.map((b, i) => (
            <div key={i} className="rounded-xl border border-slate-200 p-2.5 space-y-2">
              <div className="flex items-center gap-2">
                <input
                  className="input py-1.5 text-sm grow"
                  value={b.label}
                  onChange={(e) => updBreak(i, { label: e.target.value })}
                  placeholder="Label (e.g. Recess, Lunch)"
                />
                <button onClick={() => delBreak(i)} className="text-red-400 px-1.5">🗑️</button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="label">After period</label>
                  <select
                    className="input py-1.5 text-sm"
                    value={b.afterPeriod}
                    onChange={(e) => updBreak(i, { afterPeriod: +e.target.value })}
                  >
                    {Array.from({ length: s.periodsPerDay }).map((_, p) => (
                      <option key={p} value={p + 1}>
                        After P{p + 1}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Duration (min)</label>
                  <input
                    type="number"
                    className="input py-1.5 text-sm"
                    value={b.minutes}
                    onChange={(e) => updBreak(i, { minutes: Math.max(0, +e.target.value || 0) })}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-slate-400 mt-2">
          Breaks appear in the timetable views with their timing, and block periods won't be split
          across a break.
        </p>
      </Card>

      <p className="label px-1">Period times (auto-filled, editable)</p>
      <div className="space-y-2">
        {state.timings.map((t, i) => (
          <Card key={i} className="flex items-center gap-3">
            <span className="chip bg-brand-50 text-brand-700 shrink-0">P{i + 1}</span>
            <input type="time" className="input" value={t.start} onChange={(e) => setTiming(i, 'start', e.target.value)} />
            <span className="text-slate-400">–</span>
            <input type="time" className="input" value={t.end} onChange={(e) => setTiming(i, 'end', e.target.value)} />
            {t.breakAfter && (
              <span className="chip bg-amber-100 text-amber-700 shrink-0 text-[10px]">
                + {t.breakAfter.label}
              </span>
            )}
          </Card>
        ))}
      </div>
    </div>
  )
}
