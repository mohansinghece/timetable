import { Link } from 'react-router-dom'
import { useApp } from '../store/AppContext'
import { Card, ProgressBar, SectionTitle, StatCard } from '../components/ui'
import { DAYS, DAY_LABELS } from '../types'
import { classProgress, className, getTimetable, teacherWeek } from '../lib/timetable'

export default function Dashboard() {
  const { state, isAdmin } = useApp()
  const periods = state.settings.periodsPerDay

  // School overview
  let totalReq = 0
  let totalAsg = 0
  const classRows = state.classes.map((c) => {
    const p = classProgress(state, c.id)
    totalReq += p.required
    totalAsg += p.assigned
    return { c, ...p }
  })
  const overallPct = totalReq ? Math.round((totalAsg / totalReq) * 100) : 0

  // Day-wise fill
  const dayRows = DAYS.map((d) => {
    let filled = 0
    for (const tt of state.timetables) filled += tt.grid[d]?.filter(Boolean).length ?? 0
    const cap = state.classes.length * periods
    return { d, filled, cap }
  })

  // Teacher load
  const teacherRows = state.teachers
    .map((t) => {
      const wk = teacherWeek(state, t.id)
      const load = DAYS.reduce((a, d) => a + wk[d].filter(Boolean).length, 0)
      return { t, load }
    })
    .sort((a, b) => b.load - a.load)

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3">
        <StatCard label="Classes" value={state.classes.length} accent="bg-brand-600" />
        <StatCard label="Teachers" value={state.teachers.length} accent="bg-indigo-500" />
        <StatCard
          label="Periods Filled"
          value={`${totalAsg}/${totalReq}`}
          hint="across all classes"
          accent="bg-amber-500"
        />
        <StatCard label="Overall" value={`${overallPct}%`} hint="completion" accent="bg-emerald-500" />
      </div>

      <Card>
        <SectionTitle icon="🏫" title="School Overview" subtitle="Total timetable completion" />
        <div className="flex items-center gap-3">
          <ProgressBar value={totalAsg} total={totalReq} />
          <span className="text-sm font-bold text-slate-700 w-12 text-right">{overallPct}%</span>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-4">
          {isAdmin ? (
            <>
              <Link to="/config" className="btn-soft text-xs">⚙️ Setup</Link>
              <Link to="/timetable" className="btn-soft text-xs">📅 Build</Link>
              <Link to="/arrangement" className="btn-soft text-xs">🔁 Arrange</Link>
            </>
          ) : (
            <>
              <Link to="/view" className="btn-soft text-xs">👁️ Timetables</Link>
              <Link to="/arrangement" className="btn-soft text-xs">🔁 Arrange</Link>
              <Link to="/login" className="btn-soft text-xs">🔑 Admin</Link>
            </>
          )}
        </div>
      </Card>

      <Card>
        <SectionTitle icon="📚" title="Class-wise Fill Status" />
        <div className="space-y-3">
          {classRows.map(({ c, assigned, required }) => {
            const pct = required ? Math.round((assigned / required) * 100) : 0
            return (
              <Link
                to={isAdmin ? `/timetable/build/${c.id}` : '/view'}
                key={c.id}
                className="flex items-center gap-3 active:opacity-70"
              >
                <span className="w-14 text-sm font-bold text-slate-700 shrink-0">
                  {className(c)}
                </span>
                <ProgressBar
                  value={assigned}
                  total={required}
                  color={pct === 100 ? 'bg-emerald-500' : pct > 0 ? 'bg-brand-600' : 'bg-slate-300'}
                />
                <span className="text-xs font-semibold text-slate-500 w-16 text-right shrink-0">
                  {assigned}/{required}
                </span>
              </Link>
            )
          })}
        </div>
      </Card>

      <Card>
        <SectionTitle icon="🗓️" title="Day-wise Fill Status" />
        <div className="space-y-3">
          {dayRows.map(({ d, filled, cap }) => (
            <div key={d} className="flex items-center gap-3">
              <span className="w-24 text-sm font-semibold text-slate-700 shrink-0">
                {DAY_LABELS[d]}
              </span>
              <ProgressBar value={filled} total={cap} color="bg-indigo-500" />
              <span className="text-xs font-semibold text-slate-500 w-16 text-right shrink-0">
                {filled}/{cap}
              </span>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <SectionTitle icon="👩‍🏫" title="Teacher-wise Load" subtitle="Periods assigned per week" />
        {teacherRows.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-4">
            No teachers yet. Add them in <Link to="/config/teachers" className="text-brand-700 font-semibold">Setup → Teachers</Link>.
          </p>
        ) : (
          <div className="space-y-3">
            {teacherRows.map(({ t, load }) => (
              <div key={t.id} className="flex items-center gap-3">
                <span className="grow text-sm font-semibold text-slate-700 truncate">{t.name}</span>
                <ProgressBar value={load} total={DAYS.length * periods} color="bg-amber-500" />
                <span className="text-xs font-semibold text-slate-500 w-12 text-right shrink-0">
                  {load}
                </span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  )
}
