import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../../store/AppContext'
import { Card, ProgressBar } from '../../components/ui'
import { classProgress, className } from '../../lib/timetable'
import { STAGE_LABELS } from '../../lib/seed'

export default function TimetableHub() {
  const { state } = useApp()
  const navigate = useNavigate()

  const grouped = (['foundational', 'preparatory', 'middle', 'secondary'] as const).map((st) => ({
    stage: st,
    classes: state.classes.filter((c) => c.stage === st),
  }))

  return (
    <div className="space-y-4">
      <div className="px-1">
        <h1 className="text-lg font-extrabold text-slate-800">Build Timetable</h1>
        <p className="text-sm text-slate-500">Choose how to build, then fine-tune any class.</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => navigate('/timetable/auto')} className="card p-4 text-left active:scale-[0.99]">
          <div className="text-2xl mb-1">⚡</div>
          <p className="font-bold text-slate-800 text-sm">Auto Generate</p>
          <p className="text-xs text-slate-500">Primary / Secondary batch</p>
        </button>
        <button
          onClick={() => navigate('/timetable/manual')}
          className="card p-4 text-left active:scale-[0.99]"
        >
          <div className="text-2xl mb-1">✍️</div>
          <p className="font-bold text-slate-800 text-sm">Manual Build</p>
          <p className="text-xs text-slate-500">Day · Class · Teacher wise</p>
        </button>
      </div>

      <div id="manual-list" className="space-y-4 scroll-mt-20">
      {grouped.map(
        (g) =>
          g.classes.length > 0 && (
            <div key={g.stage}>
              <p className="label px-1">{STAGE_LABELS[g.stage]}</p>
              <div className="space-y-2">
                {g.classes.map((c) => {
                  const p = classProgress(state, c.id)
                  const pct = p.required ? Math.round((p.assigned / p.required) * 100) : 0
                  return (
                    <Link
                      to={`/timetable/build/${c.id}`}
                      key={c.id}
                      className="card p-3.5 flex items-center gap-3 active:scale-[0.99]"
                    >
                      <span className="h-11 w-11 rounded-xl bg-brand-50 grid place-items-center font-extrabold text-brand-700 shrink-0">
                        {c.grade}
                      </span>
                      <div className="grow min-w-0">
                        <p className="font-bold text-slate-800">Class {className(c)}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <ProgressBar
                            value={p.assigned}
                            total={p.required}
                            color={pct === 100 ? 'bg-emerald-500' : 'bg-brand-600'}
                          />
                          <span className="text-[11px] font-semibold text-slate-400 shrink-0">
                            {p.assigned}/{p.required}
                          </span>
                        </div>
                      </div>
                      <span className="text-slate-300 text-lg">›</span>
                    </Link>
                  )
                })}
              </div>
            </div>
          ),
      )}
      </div>
    </div>
  )
}
