import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../../store/AppContext'
import { Card, Modal, PageHeader, ProgressBar } from '../../components/ui'
import SubjectTally from '../../components/SubjectTally'
import { autoGenerateClass, className, classProgress, emptyGrid, postCode, subjectGroupKey } from '../../lib/timetable'
import { DAYS, DAY_LABELS, Stage } from '../../types'

type Batch = 'primary' | 'secondary' | 'all'

const BATCH_STAGES: Record<Batch, Stage[]> = {
  primary: ['foundational', 'preparatory'],
  secondary: ['middle', 'secondary'],
  all: ['foundational', 'preparatory', 'middle', 'secondary'],
}

export default function AutoGenerate() {
  const { state, update } = useApp()
  const navigate = useNavigate()
  const [batch, setBatch] = useState<Batch>('primary')
  const [overwrite, setOverwrite] = useState(true)
  const [peGround, setPeGround] = useState(true)
  const [selected, setSelected] = useState<string[]>([])
  const [excludedTeachers, setExcludedTeachers] = useState<string[]>([])
  // common-teacher busy (other section) is persisted in app state
  const commonBusy = state.commonBusy ?? {}
  const [busyEditor, setBusyEditor] = useState<string | null>(null)
  const [done, setDone] = useState(false)
  const [expanded, setExpanded] = useState<string[]>([])

  const periods = state.settings.periodsPerDay
  const batchClasses = state.classes.filter((c) => BATCH_STAGES[batch].includes(c.stage))
  const targetIds = selected.length ? selected : batchClasses.map((c) => c.id)
  const otherSection = batch === 'primary' ? 'Secondary' : 'Primary'

  const toggle = (arr: string[], set: (v: string[]) => void, id: string) =>
    set(arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id])

  const generate = () => {
    // Build the external "busy" set: excluded teachers blocked everywhere +
    // common teachers' marked busy slots in the other section.
    const extraBusy = new Set<string>()
    for (const tid of excludedTeachers)
      for (const d of DAYS) for (let p = 0; p < periods; p++) extraBusy.add(`${tid}|${d}|${p}`)
    for (const [tid, slots] of Object.entries(commonBusy))
      for (const key of slots) extraBusy.add(`${tid}|${key}`)

    update((d) => {
      const peBusy = new Set<string>()
      // seed from primary classes that are NOT being regenerated this run
      if (peGround) {
        for (const c of d.classes) {
          if (!(c.stage === 'foundational' || c.stage === 'preparatory')) continue
          if (targetIds.includes(c.id)) continue
          const tt = d.timetables.find((t) => t.classId === c.id)
          if (tt)
            for (const day of DAYS)
              tt.grid[day].forEach((slot, p) => {
                if (slot && subjectGroupKey(d, slot.subjectId) === 'GROUP_PE') peBusy.add(`${day}|${p}`)
              })
        }
      }

      const isPrimaryOf = (id: string) => {
        const c = d.classes.find((x) => x.id === id)
        return !!c && (c.stage === 'foundational' || c.stage === 'preparatory')
      }
      const ensureTt = (id: string) => {
        let tt = d.timetables.find((t) => t.classId === id)
        if (!tt) {
          tt = { classId: id, grid: emptyGrid(d.settings.periodsPerDay) }
          d.timetables.push(tt)
        }
        return tt
      }
      const recordPe = (id: string, grid: ReturnType<typeof emptyGrid>) => {
        if (!(peGround && isPrimaryOf(id))) return
        for (const day of DAYS)
          grid[day].forEach((slot, p) => {
            if (slot && subjectGroupKey(d, slot.subjectId) === 'GROUP_PE') peBusy.add(`${day}|${p}`)
          })
      }

      // Pass 1: locked-teacher subjects (scheduled first, can't be substituted).
      for (const id of targetIds) {
        const grid = autoGenerateClass(d, id, {
          classTeacherFirstPeriod: true,
          overwrite,
          extraBusy,
          peBusy: peGround && isPrimaryOf(id) ? peBusy : undefined,
          phase: 'locked',
        })
        ensureTt(id).grid = grid
        recordPe(id, grid)
      }
      // Pass 2: remaining subjects, built on top of the locked grid.
      for (const id of targetIds) {
        const tt = ensureTt(id)
        const grid = autoGenerateClass(d, id, {
          classTeacherFirstPeriod: true,
          overwrite,
          extraBusy,
          peBusy: peGround && isPrimaryOf(id) ? peBusy : undefined,
          phase: 'rest',
          baseGrid: tt.grid,
        })
        tt.grid = grid
        recordPe(id, grid)
      }
    })
    setDone(true)
  }

  return (
    <div>
      <PageHeader title="Auto Generate" back="/timetable" />

      <Card className="mb-3">
        <label className="label">Batch</label>
        <div className="grid grid-cols-3 gap-2">
          {(['primary', 'secondary', 'all'] as Batch[]).map((b) => (
            <button
              key={b}
              onClick={() => {
                setBatch(b)
                setSelected([])
                setDone(false)
              }}
              className={`rounded-xl py-2.5 text-xs font-bold border ${
                batch === b
                  ? 'bg-brand-700 text-white border-brand-700'
                  : 'bg-white text-slate-600 border-slate-200'
              }`}
            >
              {b === 'primary' ? 'Primary I–V' : b === 'secondary' ? 'Secondary VI–XII' : 'All'}
            </button>
          ))}
        </div>
        <p className="text-xs text-slate-500 mt-2">
          Generated in sequence so teachers aren't double-booked across classes.
        </p>
      </Card>

      <Card className="mb-3">
        <p className="label">Classes to generate ({targetIds.length})</p>
        <div className="flex flex-wrap gap-2">
          {batchClasses.map((c) => {
            const on = targetIds.includes(c.id)
            return (
              <button
                key={c.id}
                onClick={() => toggle(selected, setSelected, c.id)}
                className={`chip border ${
                  on ? 'bg-brand-600 text-white border-brand-600' : 'bg-white text-slate-600 border-slate-200'
                }`}
              >
                {className(c)}
              </button>
            )
          })}
        </div>
        <p className="text-[11px] text-slate-400 mt-2">Tap to limit. None selected = whole batch.</p>
      </Card>

      <Card className="mb-3">
        <div className="flex items-center justify-between">
          <p className="label">Teachers for this timetable</p>
          {Object.keys(commonBusy).length > 0 && (
            <button
              onClick={() => { if (confirm('Clear all saved common-teacher busy periods?')) update((d) => { d.commonBusy = {} }) }}
              className="text-[11px] font-semibold text-rose-500"
            >
              ↺ Reset common
            </button>
          )}
        </div>
        <p className="text-[11px] text-slate-400 mb-2">
          Tap a teacher to exclude them. {batch !== 'all' && `Mark a "Common" teacher to set the periods they're already busy in ${otherSection}. Saved until reset.`}
        </p>
        <div className="space-y-2">
          {state.teachers.map((t) => {
            const excluded = excludedTeachers.includes(t.id)
            const busyCount = commonBusy[t.id]?.length ?? 0
            return (
              <div
                key={t.id}
                className={`flex items-center gap-2 rounded-xl border p-2.5 ${
                  excluded ? 'border-slate-200 bg-slate-50 opacity-60' : 'border-slate-200'
                }`}
              >
                <button
                  onClick={() => toggle(excludedTeachers, setExcludedTeachers, t.id)}
                  className="grow text-left min-w-0"
                >
                  <span className="font-semibold text-slate-800 text-sm">{t.name}</span>
                  <span className="ml-2 chip bg-brand-50 text-brand-700 text-[10px]">{postCode(state, t.id)}</span>
                  {excluded && <span className="ml-2 text-[11px] text-slate-400">excluded</span>}
                </button>
                {batch !== 'all' && !excluded && (
                  <button
                    onClick={() => setBusyEditor(t.id)}
                    className={`chip text-[11px] shrink-0 ${
                      busyCount ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    🕐 Common{busyCount ? ` (${busyCount})` : '?'}
                  </button>
                )}
              </div>
            )
          })}
        </div>
      </Card>

      <Card className="mb-3 space-y-2">
        <Toggle label="Overwrite existing timetables" value={overwrite} onChange={setOverwrite} />
        <p className="text-[11px] text-slate-400 -mt-1">
          On: keep the existing timetable and only fill/assign the remaining periods (existing
          periods stay unchanged). Off: clear and rebuild from scratch.
        </p>
        <Toggle label="Prevent PE ground clash (Primary I–V)" value={peGround} onChange={setPeGround} />
        <p className="text-[11px] text-slate-400 -mt-1">
          On: no two primary classes get a Physical Education period (PE / Games & Sports / Yoga) in
          the same slot — useful when only one class can use the ground at a time.
        </p>
      </Card>

      <button onClick={generate} className="btn-primary w-full mb-4">
        ⚡ Generate {targetIds.length} timetable{targetIds.length === 1 ? '' : 's'}
      </button>

      {done && (
        <Card>
          <p className="font-bold text-slate-800 mb-3">✅ Generated. Tap a class to see its period audit:</p>
          <div className="space-y-2">
            {targetIds.map((id) => {
              const c = state.classes.find((x) => x.id === id)!
              const p = classProgress(state, id)
              const pct = p.required ? Math.round((p.assigned / p.required) * 100) : 0
              const open = expanded.includes(id)
              return (
                <div key={id}>
                  <button
                    onClick={() => setExpanded((e) => (e.includes(id) ? e.filter((x) => x !== id) : [...e, id]))}
                    className="w-full flex items-center gap-3"
                  >
                    <span className="w-14 text-sm font-bold text-slate-700 shrink-0 text-left">
                      {className(c)}
                    </span>
                    <ProgressBar value={p.assigned} total={p.required} color={pct === 100 ? 'bg-emerald-500' : 'bg-brand-600'} />
                    <span className="text-xs font-semibold text-slate-500 w-16 text-right shrink-0">
                      {p.assigned}/{p.required}
                    </span>
                    <span className="text-slate-300">{open ? '▾' : '▸'}</span>
                  </button>
                  {open && (
                    <div className="mt-2 mb-3">
                      <SubjectTally classId={id} />
                      <button
                        onClick={() => navigate(`/timetable/build/${id}`)}
                        className="btn-soft w-full text-xs mt-2"
                      >
                        ✍️ Open & edit this class
                      </button>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </Card>
      )}

      <BusyEditor
        key={busyEditor ?? 'none'}
        teacherId={busyEditor}
        otherSection={otherSection}
        periods={periods}
        value={busyEditor ? commonBusy[busyEditor] ?? [] : []}
        onClose={() => setBusyEditor(null)}
        onSave={(slots) => {
          if (busyEditor) update((d) => { d.commonBusy = { ...(d.commonBusy ?? {}), [busyEditor]: slots } })
          setBusyEditor(null)
        }}
      />
    </div>
  )
}

function BusyEditor({
  teacherId,
  otherSection,
  periods,
  value,
  onClose,
  onSave,
}: {
  teacherId: string | null
  otherSection: string
  periods: number
  value: string[]
  onClose: () => void
  onSave: (slots: string[]) => void
}) {
  const { state } = useApp()
  const [sel, setSel] = useState<string[]>(value)

  const t = teacherId ? state.teachers.find((x) => x.id === teacherId) : null
  const toggle = (k: string) =>
    setSel((c) => (c.includes(k) ? c.filter((x) => x !== k) : [...c, k]))

  return (
    <Modal
      open={!!teacherId}
      onClose={onClose}
      title={`Mark ${otherSection} Busy Periods`}
      icon="🕐"
      maxWidth="max-w-2xl"
      footer={
        <button onClick={() => onSave(sel)} className="btn-primary w-full">
          💾 Save Settings
        </button>
      }
    >
      <p className="text-sm text-slate-500 mb-3">
        Check the boxes where <b>{t?.name}</b> is busy taking classes in the {otherSection} section.
      </p>
      <div className="overflow-x-auto">
        <table className="w-full border-separate" style={{ borderSpacing: '4px' }}>
          <thead>
            <tr>
              <th className="bg-brand-600 text-white rounded-lg text-xs py-2 px-2">Day</th>
              {Array.from({ length: periods }).map((_, p) => (
                <th key={p} className="bg-brand-600 text-white rounded-lg text-xs py-2 px-1 min-w-[44px]">
                  P{p + 1}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {DAYS.map((d) => (
              <tr key={d}>
                <td className="bg-slate-100 rounded-lg text-xs font-bold text-slate-600 text-center px-2">
                  {DAY_LABELS[d].slice(0, 3)}
                </td>
                {Array.from({ length: periods }).map((_, p) => {
                  const k = `${d}|${p}`
                  const on = sel.includes(k)
                  return (
                    <td key={p} className="text-center">
                      <button
                        onClick={() => toggle(k)}
                        className={`h-9 w-full rounded-lg border-2 transition ${
                          on ? 'bg-brand-600 border-brand-600 text-white' : 'bg-slate-50 border-slate-200'
                        }`}
                      >
                        {on ? '✓' : ''}
                      </button>
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Modal>
  )
}

function Toggle({
  label,
  value,
  onChange,
}: {
  label: string
  value: boolean
  onChange: (v: boolean) => void
}) {
  return (
    <button onClick={() => onChange(!value)} className="w-full flex items-center gap-3 text-left">
      <div className={`h-6 w-11 rounded-full transition shrink-0 relative ${value ? 'bg-brand-600' : 'bg-slate-300'}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${value ? 'left-[1.4rem]' : 'left-0.5'}`} />
      </div>
      <p className="text-sm font-semibold text-slate-800">{label}</p>
    </button>
  )
}
