import { NavLink, useNavigate } from 'react-router-dom'
import React from 'react'
import { useApp } from '../store/AppContext'

const ADMIN_NAV = [
  { to: '/', label: 'Home', icon: '🏠', end: true },
  { to: '/config', label: 'Setup', icon: '⚙️' },
  { to: '/timetable', label: 'Build', icon: '📅' },
  { to: '/view', label: 'Views', icon: '👁️' },
  { to: '/arrangement', label: 'Arrange', icon: '🔁' },
]
const PUBLIC_NAV = [
  { to: '/view', label: 'Timetables', icon: '👁️', end: true },
  { to: '/arrangement', label: 'Arrangement', icon: '🔁' },
]

function SyncPill() {
  const { sync, isAdmin, saveNow } = useApp()
  if (!isAdmin) {
    return <span className="text-[10px] font-semibold bg-white/15 rounded-lg px-2 py-1">👁 View</span>
  }
  if (sync === 'unsaved') {
    return (
      <button onClick={() => saveNow()} className="text-[10px] font-semibold bg-amber-400/30 rounded-lg px-2 py-1">
        ● Unsaved — Save
      </button>
    )
  }
  const map: Record<string, { t: string; c: string }> = {
    loading: { t: 'Loading', c: 'bg-white/15' },
    online: { t: 'Synced', c: 'bg-emerald-400/25' },
    saving: { t: 'Saving…', c: 'bg-amber-400/25' },
    saved: { t: '✓ Saved', c: 'bg-emerald-400/25' },
    error: { t: '⚠ Error', c: 'bg-red-400/30' },
    offline: { t: 'Offline', c: 'bg-slate-400/30' },
  }
  const s = map[sync] ?? map.online
  return <span className={`text-[10px] font-semibold rounded-lg px-2 py-1 ${s.c}`}>{s.t}</span>
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const { state, isAdmin, logout, undo, redo, canUndo, canRedo } = useApp()
  const navigate = useNavigate()
  const nav = isAdmin ? ADMIN_NAV : PUBLIC_NAV

  return (
    <div className="min-h-full flex flex-col max-w-3xl mx-auto bg-[#eef2f9]">
      <header className="no-print sticky top-0 z-30 bg-gradient-to-br from-brand-700 via-brand-700 to-accent-700 text-white px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 shadow-soft">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="h-9 w-9 rounded-xl bg-white/15 grid place-items-center text-lg shrink-0 backdrop-blur">
              📘
            </div>
            <div className="min-w-0">
              <h1 className="font-bold leading-tight text-sm truncate">{state.settings.schoolName}</h1>
              <p className="text-[11px] text-white/70">Timetable Manager · 2025–26</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <SyncPill />
            {isAdmin && (
              <div className="flex items-center gap-1">
                <button
                  onClick={undo}
                  disabled={!canUndo}
                  title="Undo"
                  className="h-7 w-7 grid place-items-center rounded-lg bg-white/15 disabled:opacity-30 text-sm"
                >
                  ↶
                </button>
                <button
                  onClick={redo}
                  disabled={!canRedo}
                  title="Redo"
                  className="h-7 w-7 grid place-items-center rounded-lg bg-white/15 disabled:opacity-30 text-sm"
                >
                  ↷
                </button>
              </div>
            )}
            {isAdmin ? (
              <button
                onClick={() => {
                  logout()
                  navigate('/')
                }}
                className="text-xs font-semibold bg-white/15 hover:bg-white/25 rounded-lg px-3 py-1.5"
              >
                Logout
              </button>
            ) : (
              <button
                onClick={() => navigate('/login')}
                className="text-xs font-semibold bg-white/20 hover:bg-white/30 rounded-lg px-3 py-1.5"
              >
                Admin
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="grow px-4 py-4 pb-28">{children}</main>

      <nav className="no-print fixed bottom-0 inset-x-0 z-30">
        <div className="max-w-3xl mx-auto bg-white/90 backdrop-blur-lg border-t border-slate-200 px-2 pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1.5">
          <div className={`grid`} style={{ gridTemplateColumns: `repeat(${nav.length}, minmax(0, 1fr))` }}>
            {nav.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.end}
                className={({ isActive }) =>
                  `flex flex-col items-center justify-center gap-0.5 py-1.5 mx-1 rounded-xl text-[10px] font-semibold transition ${
                    isActive ? 'text-brand-700 bg-brand-50' : 'text-slate-400'
                  }`
                }
              >
                <span className="text-lg leading-none">{n.icon}</span>
                {n.label}
              </NavLink>
            ))}
          </div>
        </div>
      </nav>
    </div>
  )
}
