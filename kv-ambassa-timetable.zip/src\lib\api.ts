import { AppState } from '../types'

const TOKEN_KEY = 'kv-admin-token'

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}
export function setToken(t: string | null) {
  if (t) localStorage.setItem(TOKEN_KEY, t)
  else localStorage.removeItem(TOKEN_KEY)
}

/** Fetch the shared state from the server. Returns null if none saved yet. */
export async function fetchState(): Promise<AppState | null> {
  const r = await fetch('/api/state')
  if (!r.ok) throw new Error('fetch state failed')
  const data = await r.json()
  return (data?.state as AppState) ?? null
}

/** Verify admin password; on success returns the token to store. */
export async function apiLogin(password: string): Promise<string | null> {
  const r = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password }),
  })
  if (!r.ok) return null
  const data = await r.json()
  return (data?.token as string) ?? null
}

/** Save the whole state (admin only). */
export async function pushState(state: AppState, token: string): Promise<boolean> {
  const r = await fetch('/api/state', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', 'x-admin-token': token },
    body: JSON.stringify({ state }),
  })
  return r.ok
}
