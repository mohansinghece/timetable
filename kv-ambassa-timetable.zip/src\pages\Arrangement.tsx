import { useEffect, useMemo, useState } from 'react'
import { useApp } from '../store/AppContext'
import { Card, Modal, StatCard } from '../components/ui'
import { DAYS, Day, Teacher } from '../types'
import {
  className,
  findSubject,
  findTeacher,
  postCode,
  teacherWeek,
} from '../lib/timetable'
import { uid } from '../lib/seed'

function dayFromDate(dateStr: string): Day | null {
  if (!dateStr) return null
  const d = new Date(dateStr + 'T00:00:00')
  const idx = d.getDay() // 0 Sun .. 6 Sat
  if (idx === 0) return null // Sunday holiday
  return DAYS[idx - 1]
}

export default function Arrangement() {
  const { state, update, isAdmin, saveNow } = useApp()
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [absentOpen, setAbsentOpen] = useState(false)
  const [suspendOpen, setSuspendOpen] = useState(false)
  const [generated, setGenerated] = useState(false)
  const [peek, setPeek] = useState<string | null>(null)

  const day = dayFromDate(date)

  const arr = state.arrangements.find((a) => a.date === date)
  const absentIds = arr?.absentTeacherIds ?? []
  const suspendedIds = arr?.suspendedClassIds ?? []
  const assignments = arr?.assignments ?? {}

  // Viewers: automatically show the saved arrangement form for the date.
  useEffect(() => {
    if (!isAdmin && day && absentIds.length > 0) setGenerated(true)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin, date, absentIds.length, day])

  const periods = state.settings.periodsPerDay

  const ensureArr = (d: typeof state) => {
    let a = d.arrangements.find((x) => x.date === date)
    if (!a) {
      a = { date, absentTeacherIds: [], suspendedClassIds: [], assignments: {} }
      d.arrangements.push(a)
    }
    return a
  }

  const setAbsent = (ids: string[]) =>
    update((d) => {
      ensureArr(d).absentTeacherIds = ids
    })
  const setSuspended = (ids: string[]) =>
    update((d) => {
      ensureArr(d).suspendedClassIds = ids
    })
  const setAssignment = (key: string, patch: { coverTeacherId?: string; remarks?: string }) =>
    update((d) => {
      const a = ensureArr(d)
      a.assignments[key] = { ...a.assignments[key], ...patch }
    })

  // Periods needing cover: for each absent teacher, the periods they teach (class not suspended).
  const coverItems = useMemo(() => {
    if (!day) return []
    const items: {
      teacherId: string
      period: number
      classId: string
      subjectId: string
      suspended: boolean
    }[] = []
    for (const tid of absentIds) {
      const wk = teacherWeek(state, tid)
      wk[day].forEach((slot, p) => {
        if (slot) {
          items.push({
            teacherId: tid,
            period: p,
            classId: slot.classId,
            subjectId: slot.subjectId,
            suspended: suspendedIds.includes(slot.classId),
          })
        }
      })
    }
    return items
  }, [state, day, absentIds, suspendedIds])

  const periodsToFill = coverItems.filter((i) => !i.suspended).length
  const unassigned = coverItems.filter(
    (i) => !i.suspended && !assignments[`${i.teacherId}|${i.period}`]?.coverTeacherId,
  ).length

  /** Teachers available to cover at a given period. */
  const availableAt = (period: number, exceptKey: string): Teacher[] => {
    // teachers already assigned as cover at this period (in other items)
    const usedCovers = new Set<string>()
    for (const [k, v] of Object.entries(assignments)) {
      if (k === exceptKey) continue
      const p = Number(k.split('|')[1])
      if (p === period && v.coverTeacherId) usedCovers.add(v.coverTeacherId)
    }
    return state.teachers.filter((t) => {
      if (absentIds.includes(t.id)) return false
      if (usedCovers.has(t.id)) return false
      const wk = teacherWeek(state, t.id)
      const slot = day ? wk[day][period] : null
      if (!slot) return true // free
      // busy — unless their class is suspended
      return suspendedIds.includes(slot.classId)
    })
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <StatCard label="Absent Today" value={absentIds.length} hint="teachers selected" accent="bg-emerald-500" />
        <StatCard label="Periods to Fill" value={periodsToFill} hint="from schedule" accent="bg-indigo-500" />
        <StatCard label="Unassigned" value={unassigned} hint="still pending" accent="bg-amber-500" />
        <StatCard label="Day" value={day ?? '—'} hint={day ? 'school day' : 'holiday/Sunday'} accent="bg-rose-500" />
      </div>

      {/* Step 1 */}
      <Card>
        <h2 className="font-bold text-slate-800 mb-3">📅 Step 1 — Date & Absent / Suspended</h2>
        <label className="label">Date</label>
        <input
          type="date"
          className="input mb-4"
          value={date}
          onChange={(e) => {
            setDate(e.target.value)
            setGenerated(false)
          }}
        />

        <label className="label">Absent Teachers</label>
        {isAdmin && (
          <button
            onClick={() => setAbsentOpen(true)}
            className="w-full rounded-xl border-2 border-dashed border-emerald-300 p-3 flex items-center gap-3 mb-2"
          >
            <span className="h-10 w-10 rounded-xl bg-emerald-600 grid place-items-center text-white text-lg shrink-0">
              👥
            </span>
            <div className="text-left grow">
              <p className="font-bold text-emerald-700">Select Absent Teachers</p>
              <p className="text-xs text-emerald-600/80">Browse by PRT · TGT · PGT · Misc</p>
            </div>
            <span className="text-emerald-400">›</span>
          </button>
        )}
        {absentIds.length > 0 ? (
          <div className="flex flex-wrap gap-2 mb-4">
            {absentIds.map((id) => {
              const t = findTeacher(state, id)
              return (
                <span key={id} className="chip bg-emerald-100 text-emerald-800">
                  {t?.name ?? '?'} <span className="opacity-70">{postCode(state, id)}</span>
                  {isAdmin && (
                    <button onClick={() => setAbsent(absentIds.filter((x) => x !== id))} className="ml-1">✕</button>
                  )}
                </span>
              )
            })}
          </div>
        ) : (
          !isAdmin && <p className="text-sm text-slate-400 mb-4">No teachers marked absent for this date.</p>
        )}

        <label className="label">Suspended Classes</label>
        {isAdmin && (
          <button
            onClick={() => setSuspendOpen(true)}
            className="w-full rounded-xl border-2 border-dashed border-rose-300 p-3 flex items-center gap-3 mb-2"
          >
            <span className="h-10 w-10 rounded-xl bg-rose-500 grid place-items-center text-white text-lg shrink-0">
              🚫
            </span>
            <div className="text-left grow">
              <p className="font-bold text-rose-600">Select Suspended Classes</p>
              <p className="text-xs text-rose-500/80">Teachers will be freed for arrangement</p>
            </div>
            <span className="text-rose-400">›</span>
          </button>
        )}
        {suspendedIds.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {suspendedIds.map((id) => {
              const c = state.classes.find((x) => x.id === id)
              return (
                <span key={id} className="chip bg-rose-100 text-rose-700">
                  {c ? className(c) : '?'}
                  {isAdmin && (
                    <button onClick={() => setSuspended(suspendedIds.filter((x) => x !== id))} className="ml-1">✕</button>
                  )}
                </span>
              )
            })}
          </div>
        )}

        {isAdmin && (
          <button
            onClick={() => setGenerated(true)}
            disabled={!day || absentIds.length === 0}
            className="btn-soft w-full mt-2"
          >
            ⚡ Step 2 — Generate Arrangement Form →
          </button>
        )}
        {!day && (
          <p className="text-xs text-rose-500 mt-2 text-center">
            Selected date is a Sunday/holiday — no periods to arrange.
          </p>
        )}
      </Card>

      {/* Step 2 */}
      {generated && day && (
        <>
          {absentIds.map((tid) => {
            const t = findTeacher(state, tid)
            const items = coverItems.filter((i) => i.teacherId === tid)
            return (
              <div key={tid} className="rounded-2xl overflow-hidden border border-slate-200">
                <div className="bg-slate-900 text-white px-4 py-2.5 flex items-center justify-between">
                  <span className="font-bold text-sm">
                    <span className="text-rose-400">● </span>Absent: {t?.name}
                  </span>
                  <span className="chip bg-white/10 text-white text-[10px]">{postCode(state, tid)}</span>
                </div>
                <div className="bg-white p-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {Array.from({ length: periods }).map((_, p) => {
                    const item = items.find((i) => i.period === p)
                    const key = `${tid}|${p}`
                    const cls = item ? state.classes.find((c) => c.id === item.classId) : null
                    const colors = [
                      'bg-violet-50 text-violet-600',
                      'bg-purple-50 text-purple-600',
                      'bg-emerald-50 text-emerald-600',
                      'bg-amber-50 text-amber-600',
                      'bg-rose-50 text-rose-600',
                      'bg-cyan-50 text-cyan-600',
                      'bg-pink-50 text-pink-600',
                      'bg-indigo-50 text-indigo-600',
                    ]
                    return (
                      <div key={p} className="rounded-xl border border-slate-100 p-2 text-center">
                        <span className={`chip text-[9px] ${colors[p % colors.length]}`}>
                          PERIOD {p + 1}
                        </span>
                        {!item ? (
                          <p className="text-slate-300 italic text-xs py-4">Free</p>
                        ) : item.suspended ? (
                          <p className="text-rose-400 italic text-xs py-4">Suspended</p>
                        ) : (
                          <>
                            <p className="font-extrabold text-slate-800 mt-1 leading-tight">
                              {cls ? className(cls) : '?'}
                            </p>
                            <p className="text-[10px] text-slate-500 mb-1.5">
                              {findSubject(state, item.subjectId)?.acronym}
                            </p>
                            {isAdmin ? (
                              <>
                                <div className="flex gap-1">
                                  <select
                                    className="input py-1 px-1 text-[11px] grow"
                                    value={assignments[key]?.coverTeacherId ?? ''}
                                    onChange={(e) => setAssignment(key, { coverTeacherId: e.target.value })}
                                  >
                                    <option value="">Assign…</option>
                                    {availableAt(p, key).map((ct) => (
                                      <option key={ct.id} value={ct.id}>
                                        {ct.name}
                                      </option>
                                    ))}
                                  </select>
                                  {assignments[key]?.coverTeacherId && (
                                    <button
                                      onClick={() => setPeek(assignments[key].coverTeacherId!)}
                                      className="h-7 w-7 rounded-lg border border-slate-200 text-xs shrink-0"
                                      title="See this teacher's day"
                                    >
                                      📋
                                    </button>
                                  )}
                                </div>
                                <input
                                  className="input py-1 px-2 text-[11px] mt-1"
                                  placeholder="Remarks…"
                                  value={assignments[key]?.remarks ?? ''}
                                  onChange={(e) => setAssignment(key, { remarks: e.target.value })}
                                />
                              </>
                            ) : (
                              <>
                                <p
                                  className={`text-[11px] font-semibold rounded-lg py-1 ${
                                    assignments[key]?.coverTeacherId
                                      ? 'bg-emerald-50 text-emerald-700'
                                      : 'bg-amber-50 text-amber-600'
                                  }`}
                                >
                                  {assignments[key]?.coverTeacherId
                                    ? findTeacher(state, assignments[key].coverTeacherId!)?.name ?? '—'
                                    : 'Not assigned'}
                                </p>
                                {assignments[key]?.remarks && (
                                  <p className="text-[10px] text-slate-400 mt-1">{assignments[key].remarks}</p>
                                )}
                              </>
                            )}
                          </>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })}

          {isAdmin ? (
            <button
              onClick={async () => {
                await saveNow()
                alert('Arrangements saved & synced.')
              }}
              className="btn-primary w-full sticky bottom-24"
            >
              💾 Save Arrangements
            </button>
          ) : (
            <p className="text-center text-xs text-slate-400 py-2">Read-only view · ask admin to edit</p>
          )}
        </>
      )}

      <AbsentModal
        open={absentOpen}
        onClose={() => setAbsentOpen(false)}
        selected={absentIds}
        onConfirm={(ids) => {
          setAbsent(ids)
          setAbsentOpen(false)
        }}
      />
      <SuspendModal
        open={suspendOpen}
        onClose={() => setSuspendOpen(false)}
        selected={suspendedIds}
        onConfirm={(ids) => {
          setSuspended(ids)
          setSuspendOpen(false)
        }}
      />
      <PeekModal teacherId={peek} day={day} onClose={() => setPeek(null)} suspendedIds={suspendedIds} />
    </div>
  )
}

// ===== Modals =====

function AbsentModal({
  open,
  onClose,
  selected,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  selected: string[]
  onConfirm: (ids: string[]) => void
}) {
  const { state, update } = useApp()
  const [sel, setSel] = useState<string[]>(selected)
  const [tab, setTab] = useState<'all' | 'PRT' | 'TGT' | 'PGT' | 'Misc'>('all')
  const [q, setQ] = useState('')

  useEffect(() => {
    if (open) setSel(selected)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const codeOf = (t: Teacher) => postCode(state, t.id)
  const bucket = (t: Teacher): 'PRT' | 'TGT' | 'PGT' | 'Misc' => {
    const c = codeOf(t)
    return c === 'PRT' || c === 'TGT' || c === 'PGT' ? c : 'Misc'
  }
  const counts = {
    all: state.teachers.length,
    PRT: state.teachers.filter((t) => bucket(t) === 'PRT').length,
    TGT: state.teachers.filter((t) => bucket(t) === 'TGT').length,
    PGT: state.teachers.filter((t) => bucket(t) === 'PGT').length,
    Misc: state.teachers.filter((t) => bucket(t) === 'Misc').length,
  }
  const list = state.teachers
    .filter((t) => (tab === 'all' ? true : bucket(t) === tab))
    .filter((t) => t.name.toLowerCase().includes(q.toLowerCase()))

  const toggle = (id: string) =>
    setSel((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]))

  const addAdHoc = () => {
    const name = prompt('Ad-hoc teacher name?')
    if (!name?.trim()) return
    const id = uid()
    update((d) => {
      d.teachers.push({
        id,
        name: name.trim(),
        acronym: '',
        postId: d.posts[0]?.id ?? 'prt',
      })
    })
    setSel((c) => [...c, id])
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Select Absent Teachers"
      icon="👥"
      footer={
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-500">{sel.length} selected</span>
            <div className="flex gap-2">
              <button onClick={() => setSel([])} className="btn-ghost text-xs">Clear All</button>
              <button onClick={() => onConfirm(sel)} className="btn-primary text-xs">✓ Confirm</button>
            </div>
          </div>
          <button onClick={addAdHoc} className="btn-soft w-full text-xs">+ Missing a Teacher? Add Ad-Hoc</button>
        </div>
      }
    >
      <div className="flex gap-3 border-b border-slate-100 pb-2 mb-3 text-sm overflow-x-auto no-scrollbar">
        {(['all', 'PRT', 'TGT', 'PGT', 'Misc'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`font-semibold shrink-0 flex items-center gap-1 ${
              tab === t ? 'text-brand-700' : 'text-slate-400'
            }`}
          >
            {t === 'all' ? 'All' : t}
            <span className="chip bg-slate-100 text-slate-500 text-[10px]">{counts[t]}</span>
          </button>
        ))}
      </div>
      <input className="input mb-3" placeholder="Search teacher name…" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="grid grid-cols-2 gap-2">
        {list.map((t) => (
          <button
            key={t.id}
            onClick={() => toggle(t.id)}
            className={`rounded-xl border p-3 text-left ${
              sel.includes(t.id) ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200'
            }`}
          >
            <p className="font-bold text-slate-800 text-sm leading-tight">{t.name}</p>
            <span className="chip bg-indigo-50 text-indigo-600 text-[10px] mt-1">{codeOf(t)}</span>
          </button>
        ))}
      </div>
    </Modal>
  )
}

function SuspendModal({
  open,
  onClose,
  selected,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  selected: string[]
  onConfirm: (ids: string[]) => void
}) {
  const { state } = useApp()
  const [sel, setSel] = useState<string[]>(selected)
  const [q, setQ] = useState('')

  useEffect(() => {
    if (open) setSel(selected)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const toggle = (id: string) =>
    setSel((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]))
  const list = state.classes.filter((c) => className(c).toLowerCase().includes(q.toLowerCase()))

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Suspended Classes"
      icon="🚫"
      footer={
        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-500">{sel.length} class(es) selected</span>
          <div className="flex gap-2">
            <button onClick={() => setSel([])} className="btn-ghost text-xs">Clear All</button>
            <button onClick={() => onConfirm(sel)} className="btn-danger text-xs">✓ Confirm</button>
          </div>
        </div>
      }
    >
      <input className="input mb-3" placeholder="Search class name…" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="grid grid-cols-3 gap-2">
        {list.map((c) => (
          <button
            key={c.id}
            onClick={() => toggle(c.id)}
            className={`rounded-xl border p-3 font-bold text-slate-800 ${
              sel.includes(c.id) ? 'border-rose-500 bg-rose-50' : 'border-slate-200'
            }`}
          >
            {className(c)}
          </button>
        ))}
      </div>
    </Modal>
  )
}

function PeekModal({
  teacherId,
  day,
  onClose,
  suspendedIds,
}: {
  teacherId: string | null
  day: Day | null
  onClose: () => void
  suspendedIds: string[]
}) {
  const { state } = useApp()
  if (!teacherId || !day) return null
  const t = findTeacher(state, teacherId)
  const wk = teacherWeek(state, teacherId)
  return (
    <Modal open={!!teacherId} onClose={onClose} title={t?.name ?? 'Teacher'} icon="📋" maxWidth="max-w-md">
      <p className="text-xs text-slate-500 mb-2">Schedule for {day}</p>
      <div className="grid grid-cols-4 gap-2">
        {wk[day].map((s, i) => {
          const c = s ? state.classes.find((x) => x.id === s.classId) : null
          const suspended = s && suspendedIds.includes(s.classId)
          return (
            <div
              key={i}
              className={`rounded-xl border p-2 text-center ${
                !s ? 'border-slate-100 bg-slate-50' : suspended ? 'border-rose-200 bg-rose-50' : 'border-brand-200 bg-brand-50'
              }`}
            >
              <p className="text-[10px] font-bold text-slate-400">P{i + 1}</p>
              {s ? (
                <>
                  <p className="text-sm font-extrabold text-slate-800">{c ? className(c) : '?'}</p>
                  <p className="text-[10px] text-slate-500">{findSubject(state, s.subjectId)?.acronym}</p>
                  {suspended && <p className="text-[9px] text-rose-500">suspended</p>}
                </>
              ) : (
                <p className="text-[11px] text-slate-300 mt-1">Free</p>
              )}
            </div>
          )
        })}
      </div>
    </Modal>
  )
}
