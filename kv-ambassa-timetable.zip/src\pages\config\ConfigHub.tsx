import { Link } from 'react-router-dom'
import { useApp } from '../../store/AppContext'

const STEPS = [
  { to: '/config/classes', icon: '🏫', title: 'Classes & Sections', desc: 'Add classes I–XII and sections' },
  { to: '/config/posts', icon: '🏷️', title: 'Posts / Designations', desc: 'PRT, TGT, PGT, Librarian…' },
  { to: '/config/subjects', icon: '📖', title: 'Subjects', desc: 'Names & acronyms' },
  { to: '/config/teachers', icon: '👩‍🏫', title: 'Teachers', desc: 'Name, post & subjects taught' },
  { to: '/config/class-teachers', icon: '⭐', title: 'Class Teachers', desc: 'Assign class & co-class teacher' },
  { to: '/config/class-subjects', icon: '🧮', title: 'Subjects per Class', desc: 'Periods/week & block periods' },
  { to: '/config/timings', icon: '⏰', title: 'Period Timings', desc: 'Period & recess timings' },
  { to: '/settings', icon: '🔧', title: 'Settings & Data', desc: 'Password, import/export, reset' },
]

export default function ConfigHub() {
  const { state } = useApp()
  const counts: Record<string, string> = {
    '/config/classes': `${state.classes.length} classes`,
    '/config/posts': `${state.posts.length} posts`,
    '/config/subjects': `${state.subjects.length} subjects`,
    '/config/teachers': `${state.teachers.length} teachers`,
  }
  return (
    <div className="space-y-3">
      <div className="px-1">
        <h1 className="text-lg font-extrabold text-slate-800">Configure Timetable</h1>
        <p className="text-sm text-slate-500">Set these up in order for the best results.</p>
      </div>
      {STEPS.map((s, i) => (
        <Link key={s.to} to={s.to} className="card p-4 flex items-center gap-3 active:scale-[0.99] transition">
          <div className="h-11 w-11 rounded-xl bg-brand-50 grid place-items-center text-xl shrink-0">
            {s.icon}
          </div>
          <div className="grow min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-brand-700 bg-brand-50 rounded px-1.5 py-0.5">
                {i + 1}
              </span>
              <h3 className="font-bold text-slate-800 truncate">{s.title}</h3>
            </div>
            <p className="text-xs text-slate-500 truncate">{counts[s.to] ?? s.desc}</p>
          </div>
          <span className="text-slate-300 text-lg">›</span>
        </Link>
      ))}
    </div>
  )
}
