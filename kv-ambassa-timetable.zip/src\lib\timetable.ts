import {
  AppState,
  ClassGrid,
  ClassSubjectItem,
  Day,
  DAYS,
  SchoolClass,
  Slot,
  Subject,
  Teacher,
  Timetable,
} from '../types'

export function emptyGrid(periods: number): ClassGrid {
  const g = {} as ClassGrid
  for (const d of DAYS) g[d] = Array.from({ length: periods }, () => null)
  return g
}

export function getTimetable(state: AppState, classId: string): Timetable {
  const found = state.timetables.find((t) => t.classId === classId)
  if (found) return found
  return { classId, grid: emptyGrid(state.settings.periodsPerDay) }
}

export function className(c: SchoolClass): string {
  return `${c.grade} ${c.section}`
}

export function findClass(state: AppState, id: string) {
  return state.classes.find((c) => c.id === id)
}
export function findTeacher(state: AppState, id: string) {
  return state.teachers.find((t) => t.id === id)
}
export function findSubject(state: AppState, id: string) {
  return state.subjects.find((s) => s.id === id)
}
export function subjectAcr(state: AppState, id: string): string {
  return state.subjects.find((s) => s.id === id)?.acronym ?? '?'
}

/** Subject label for timetable cells. Sub-subjects (Visual Arts, Performing
 *  Arts, Games & Sports, Yoga) are shown by their own name — the Arts Education
 *  / Physical Education (PE) grouping is only a config-level parent. */
export function cellSubject(state: AppState, id: string): { acr: string; name: string } {
  const s = state.subjects.find((x) => x.id === id)
  if (!s) return { acr: '?', name: '?' }
  return { acr: s.acronym, name: s.name }
}

/** Parent group key for scheduling: Visual/Performing Arts share one group,
 *  PE/Games & Sports/Yoga share another. Grouped subjects count together for the
 *  per-day limit (so e.g. Games & Sports and Yoga can't both be on the same day). */
export function subjectGroupKey(state: AppState, id: string): string {
  const s = state.subjects.find((x) => x.id === id)
  if (!s) return id
  const n = s.name.toLowerCase()
  if (n.includes('visual art') || n.includes('performing art')) return 'GROUP_ARTS'
  if (n.includes('games') || n.includes('yoga') || n.includes('physical education')) return 'GROUP_PE'
  return id
}

const COLOR_PALETTE = [
  '#fca5a5', '#93c5fd', '#86efac', '#fdba74', '#c4b5fd', '#5eead4', '#f0abfc', '#fcd34d',
  '#67e8f9', '#a5b4fc', '#6ee7b7', '#fda4af', '#bef264', '#7dd3fc', '#f9a8d4', '#fde047',
]
/** Display colour for a subject (admin-set, else a stable default from a palette). */
export function subjectColor(state: AppState, id: string): string {
  const s = state.subjects.find((x) => x.id === id)
  if (s?.color) return s.color
  const key = s?.acronym ?? id
  let h = 0
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0
  return COLOR_PALETTE[h % COLOR_PALETTE.length]
}

/** 1-based period numbers after which a break occurs. */
function breakAfterSet(settings: AppState['settings']): Set<number> {
  const breaks =
    settings.breaks && settings.breaks.length
      ? settings.breaks
      : [{ afterPeriod: settings.recessAfterPeriod, minutes: settings.recessMinutes, label: 'Recess' }]
  return new Set(breaks.map((b) => b.afterPeriod))
}

/** Persistent common-teacher busy slots as a `${teacherId}|${day}|${period}` set. */
export function commonExtraBusy(state: AppState): Set<string> {
  const set = new Set<string>()
  const cb = state.commonBusy ?? {}
  for (const [tid, slots] of Object.entries(cb)) for (const s of slots) set.add(`${tid}|${s}`)
  return set
}

/** Is a teacher marked common-busy (other section) at this slot? */
export function isCommonBusy(state: AppState, teacherId: string, day: Day, period: number): boolean {
  return (state.commonBusy?.[teacherId] ?? []).includes(`${day}|${period}`)
}
export function postCode(state: AppState, teacherId?: string): string {
  const t = teacherId ? findTeacher(state, teacherId) : undefined
  if (!t) return ''
  return state.posts.find((p) => p.id === t.postId)?.code ?? ''
}

/** Set of `${teacherId}|${day}|${period}` occupied across all classes (optionally excluding one). */
export function buildBusyMap(state: AppState, exceptClassId?: string): Set<string> {
  const busy = new Set<string>()
  for (const tt of state.timetables) {
    if (tt.classId === exceptClassId) continue
    for (const d of DAYS) {
      tt.grid[d]?.forEach((slot, p) => {
        if (slot && slot.teacherId) busy.add(`${slot.teacherId}|${d}|${p}`)
      })
    }
  }
  return busy
}

/** Teachers who are free at a given day/period across the whole school. */
export function freeTeachersAt(
  state: AppState,
  day: Day,
  period: number,
  opts: { exceptClassId?: string } = {},
): Teacher[] {
  const busy = buildBusyMap(state, opts.exceptClassId)
  return state.teachers.filter((t) => !busy.has(`${t.id}|${day}|${period}`))
}

/** Is the teacher busy at this slot (in any class, optionally excluding one)? */
export function isTeacherBusy(
  state: AppState,
  teacherId: string,
  day: Day,
  period: number,
  exceptClassId?: string,
): boolean {
  return buildBusyMap(state, exceptClassId).has(`${teacherId}|${day}|${period}`)
}

export interface SubjectProgress {
  subjectId: string
  acronym: string
  name: string
  required: number
  assigned: number
}

export function classProgress(state: AppState, classId: string): {
  rows: SubjectProgress[]
  assigned: number
  required: number
} {
  const cfg = state.classSubjects.find((c) => c.classId === classId)
  const tt = getTimetable(state, classId)
  const counts: Record<string, number> = {}
  for (const d of DAYS) {
    for (const slot of tt.grid[d] ?? []) {
      if (slot?.subjectId) counts[slot.subjectId] = (counts[slot.subjectId] ?? 0) + 1
    }
  }
  const rows: SubjectProgress[] = (cfg?.items ?? []).map((it) => {
    const s = findSubject(state, it.subjectId)
    return {
      subjectId: it.subjectId,
      acronym: s?.acronym ?? '?',
      name: s?.name ?? '?',
      required: it.periodsPerWeek,
      assigned: counts[it.subjectId] ?? 0,
    }
  })
  const required = rows.reduce((a, r) => a + r.required, 0)
  const assigned = rows.reduce((a, r) => a + Math.min(r.assigned, r.required), 0)
  return { rows, assigned, required }
}

/** Total filled cells across a class grid. */
export function filledCount(grid: ClassGrid): number {
  let n = 0
  for (const d of DAYS) for (const s of grid[d] ?? []) if (s) n++
  return n
}

/** Total periods a teacher is assigned across the whole week. */
export function teacherWorkload(state: AppState, teacherId: string): number {
  let n = 0
  for (const tt of state.timetables)
    for (const d of DAYS)
      for (const s of tt.grid[d] ?? []) if (s?.teacherId === teacherId) n++
  return n
}

/** What a teacher is doing at a slot (class + subject), or null if free. */
export function teacherSlot(
  state: AppState,
  teacherId: string,
  day: Day,
  period: number,
  exceptClassId?: string,
): { classId: string; subjectId: string } | null {
  for (const tt of state.timetables) {
    if (tt.classId === exceptClassId) continue
    const s = tt.grid[day]?.[period]
    if (s && s.teacherId === teacherId) return { classId: tt.classId, subjectId: s.subjectId }
  }
  return null
}

/** Subjects of a class that still need periods assigned (remaining > 0). */
export function pendingForClass(
  state: AppState,
  classId: string,
): { subjectId: string; acronym: string; name: string; left: number; teacherId?: string }[] {
  const cfg = state.classSubjects.find((c) => c.classId === classId)
  const prog = classProgress(state, classId)
  return prog.rows
    .map((r) => ({
      subjectId: r.subjectId,
      acronym: r.acronym,
      name: r.name,
      left: r.required - r.assigned,
      teacherId: cfg?.items.find((i) => i.subjectId === r.subjectId)?.teacherId,
    }))
    .filter((r) => r.left > 0)
}

// ===== Teacher weekly view =====
export interface TeacherSlot {
  classId: string
  subjectId: string
}
export type TeacherWeek = Record<Day, (TeacherSlot | null)[]>

export function teacherWeek(state: AppState, teacherId: string): TeacherWeek {
  const week = {} as TeacherWeek
  for (const d of DAYS) week[d] = Array.from({ length: state.settings.periodsPerDay }, () => null)
  for (const tt of state.timetables) {
    for (const d of DAYS) {
      tt.grid[d]?.forEach((slot, p) => {
        if (slot && slot.teacherId === teacherId) {
          week[d][p] = { classId: tt.classId, subjectId: slot.subjectId }
        }
      })
    }
  }
  return week
}

// ===== Auto generation =====

export interface AutoOptions {
  /** Limit generation to these class ids (e.g. primary or secondary batch). */
  classIds: string[]
  /** Reserve period 1 each day for the class teacher. */
  classTeacherFirstPeriod: boolean
  /** Overwrite existing timetable for these classes. */
  overwrite: boolean
}

interface PlaceUnit {
  subjectId: string
  block: boolean
  teacherId: string
}

/** Teacher period-queue for a subject in a class: one teacherId per period to
 *  place. Supports single-teacher and multi-teacher (split) subjects. */
function teacherQueueFor(
  state: AppState,
  cls: SchoolClass,
  it: {
    subjectId: string
    periodsPerWeek: number
    teacherId?: string
    multiTeacher?: boolean
    teachers?: { teacherId: string; periods: number }[]
  },
): string[] {
  const q: string[] = []
  if (it.multiTeacher && it.teachers && it.teachers.length) {
    for (const t of it.teachers) for (let i = 0; i < Math.max(0, t.periods); i++) q.push(t.teacherId)
  } else if (it.teacherId) {
    for (let i = 0; i < it.periodsPerWeek; i++) q.push(it.teacherId)
  } else if (it.subjectId === claId(state) && cls.classTeacherId) {
    for (let i = 0; i < it.periodsPerWeek; i++) q.push(cls.classTeacherId)
  } else {
    for (let i = 0; i < it.periodsPerWeek; i++) q.push('') // unassigned
  }
  return q
}

/** The teacher assigned to a subject in a class (from Subjects-per-Class). */
function subjectTeacherFor(
  state: AppState,
  cls: SchoolClass,
  cfg: { items: { subjectId: string; teacherId?: string }[] },
  subjectId: string,
): string {
  const it = cfg.items.find((i) => i.subjectId === subjectId)
  if (it?.teacherId) return it.teacherId
  // CLA falls back to the class teacher if no explicit teacher chosen.
  if (subjectId === claId(state) && cls.classTeacherId) return cls.classTeacherId
  return '' // unassigned — admin fixes manually
}

/**
 * Greedy auto-fill for a single class. Returns a grid (does not mutate state).
 * `extraBusy` is a set of `${teacherId}|${day}|${period}` slots that must be
 * treated as occupied (e.g. a common teacher's periods in the other section).
 * When `overwrite` is true the existing grid is kept and only remaining periods
 * are filled (existing periods are preserved); when false the grid is rebuilt.
 */
export function autoGenerateClass(
  state: AppState,
  classId: string,
  opts: {
    classTeacherFirstPeriod: boolean
    overwrite: boolean
    extraBusy?: Set<string>
    /** Slots (`day|period`) where PE-group is already used by another class. */
    peBusy?: Set<string>
    /** Limit to locked-teacher subjects, or to the rest (for two-pass generation). */
    phase?: 'locked' | 'rest'
    /** Existing grid to build on top of (preserves placed periods). */
    baseGrid?: ClassGrid
  },
): ClassGrid {
  const cls = findClass(state, classId)
  const cfg = state.classSubjects.find((c) => c.classId === classId)
  const periods = state.settings.periodsPerDay
  if (!cls || !cfg) return emptyGrid(periods)

  const extraBusy = opts.extraBusy ?? new Set<string>()
  const busyAt = (tid: string, d: Day, p: number) =>
    isTeacherBusy(state, tid, d, p, classId) || extraBusy.has(`${tid}|${d}|${p}`)

  // Filter subjects by phase: locked-teacher subjects are scheduled first.
  const filteredItems =
    opts.phase === 'locked'
      ? cfg.items.filter((i) => i.lockTeacher)
      : opts.phase === 'rest'
        ? cfg.items.filter((i) => !i.lockTeacher)
        : cfg.items

  const fpTeacher =
    cls.firstPeriodTeacherId || (opts.classTeacherFirstPeriod ? cls.classTeacherId : undefined)
  return buildGrid(state, classId, cls, { items: filteredItems }, fpTeacher, busyAt, opts.peBusy, opts.baseGrid)
}

/**
 * Build a complete class grid: first compute a feasible per-day quota for each
 * subject (so totals always work out and every cell can be filled), then lay
 * out each day with block subjects as adjacent pairs, CLA pinned to its slot,
 * and the first-period teacher reserved for period 1.
 */
function buildGrid(
  state: AppState,
  classId: string,
  cls: SchoolClass,
  cfg: { items: ClassSubjectItem[] },
  fpTeacher: string | undefined,
  busyAt: (tid: string, d: Day, p: number) => boolean,
  peBusy?: Set<string>,
  baseGrid?: ClassGrid,
): ClassGrid {
  const P = state.settings.periodsPerDay
  const D = DAYS.length
  const items = cfg.items.filter((it) => teacherQueueFor(state, cls, it).length > 0)
  const queues: string[][] = items.map((it) => teacherQueueFor(state, cls, it))
  const req = queues.map((q) => q.length)
  const maxDay = (i: number) => (items[i].block ? 2 : 1)
  const gkey = items.map((it) => subjectGroupKey(state, it.subjectId))
  const grouped = gkey.map((k) => k.startsWith('GROUP_'))

  // Grid we build on (existing periods from a prior pass are preserved).
  const grid = baseGrid ? cloneGrid(baseGrid) : emptyGrid(P)
  const baseDaySubj = (di: number, sid: string) =>
    grid[DAYS[di]].filter((s) => s?.subjectId === sid).length
  const baseDayGroup = (di: number, gk: string) =>
    grid[DAYS[di]].filter((s) => s && subjectGroupKey(state, s.subjectId) === gk).length

  // ---- Phase A: per-day quota q[itemIndex][dayIndex] ----
  const q: number[][] = items.map(() => DAYS.map(() => 0))
  const cap = DAYS.map((_, di) => P - grid[DAYS[di]].filter(Boolean).length)
  const need = req.slice()
  const groupCount = (si: number, di: number) =>
    items.reduce((a, _, j) => a + (gkey[j] === gkey[si] ? q[j][di] : 0), 0) + baseDayGroup(di, gkey[si])
  const canAddDay = (si: number, di: number) => {
    if (cap[di] <= 0) return false
    if (grouped[si]) return groupCount(si, di) < 1
    return q[si][di] + baseDaySubj(di, items[si].subjectId) < maxDay(si)
  }
  const addQ = (si: number, di: number) => {
    q[si][di]++
    cap[di]--
    need[si]--
  }

  items.forEach((it, si) => {
    if (it.fixedDay && it.fixedStartPeriod != null) {
      const di = DAYS.indexOf(it.fixedDay)
      if (di < 0) return
      const span = it.block ? 2 : 1
      for (let k = 0; k < span; k++) if (need[si] > 0 && canAddDay(si, di)) addQ(si, di)
    }
  })
  items.forEach((it, si) => {
    if (!it.main) return
    for (let di = 0; di < D; di++) if (need[si] > 0 && canAddDay(si, di)) addQ(si, di)
  })
  let safety = 0
  while (need.some((n) => n > 0) && safety++ < 5000) {
    let si = -1
    for (let i = 0; i < items.length; i++) if (need[i] > 0 && (si < 0 || need[i] > need[si])) si = i
    if (si < 0) break
    let di = -1
    for (let dd = 0; dd < D; dd++)
      if (canAddDay(si, dd) && (di < 0 || cap[dd] > cap[di])) di = dd
    if (di >= 0) {
      addQ(si, di)
      continue
    }
    // stuck: free capacity on a day where this subject still has room
    let fixed = false
    for (let d2 = 0; d2 < D && !fixed; d2++) {
      if (
        grouped[si]
          ? groupCount(si, d2) >= 1
          : q[si][d2] + baseDaySubj(d2, items[si].subjectId) >= maxDay(si)
      )
        continue
      for (let t = 0; t < items.length && !fixed; t++) {
        if (t === si || q[t][d2] <= 0) continue
        for (let d3 = 0; d3 < D; d3++) {
          if (d3 === d2) continue
          if (canAddDay(t, d3)) {
            q[t][d2]--
            q[t][d3]++
            cap[d3]--
            cap[d2]++
            if (canAddDay(si, d2)) addQ(si, d2)
            else {
              // revert if it didn't actually help
              q[t][d2]++
              q[t][d3]--
              cap[d3]++
              cap[d2]--
              continue
            }
            fixed = true
            break
          }
        }
      }
    }
    if (!fixed) break
  }

  // ---- Phase B: arrange each day ----
  for (let di = 0; di < D; di++) {
    arrangeDay(
      state,
      grid,
      DAYS[di],
      items,
      items.map((_, si) => q[si][di]),
      queues,
      fpTeacher,
      busyAt,
      peBusy,
    )
  }
  return grid
}

/** Lay out one day's quota into period slots. */
function arrangeDay(
  state: AppState,
  grid: ClassGrid,
  d: Day,
  items: ClassSubjectItem[],
  dayQ: number[],
  queues: string[][],
  fpTeacher: string | undefined,
  busyAt: (tid: string, d: Day, p: number) => boolean,
  peBusy?: Set<string>,
): void {
  const P = state.settings.periodsPerDay
  const recessAfter = state.settings.recessAfterPeriod
  const breaks = breakAfterSet(state.settings)
  const slots = grid[d]
  const isPe = (si: number) => subjectGroupKey(state, items[si].subjectId) === 'GROUP_PE'
  const slotBlocked = (si: number, p: number) =>
    !!peBusy && isPe(si) && peBusy.has(`${d}|${p}`)
  // a teacher for this subject is free (across all classes) at this period
  const hasFree = (si: number, p: number) => queues[si].some((t) => !t || !busyAt(t, d, p))

  const takeFree = (si: number, p: number): string => {
    const queue = queues[si]
    if (queue.length === 0) return ''
    let idx = queue.findIndex((t) => !t || !busyAt(t, d, p))
    if (idx < 0) idx = 0
    const t = queue[idx]
    queue.splice(idx, 1)
    return t
  }
  const place = (si: number, p: number) => {
    slots[p] = { subjectId: items[si].subjectId, teacherId: takeFree(si, p) }
    dayQ[si]--
  }

  // 1) pinned (CLA fixed slot)
  items.forEach((it, si) => {
    if (dayQ[si] <= 0 || it.fixedDay !== d || it.fixedStartPeriod == null) return
    const span = Math.min(dayQ[si], it.block ? 2 : 1)
    for (let k = 0; k < span; k++) {
      const p = it.fixedStartPeriod + k
      if (p < P && !slots[p] && hasFree(si, p)) place(si, p)
    }
  })

  // 2) first-period teacher at P1 (+ adjacent P2 if it's a block needing 2)
  if (fpTeacher && !slots[0] && !busyAt(fpTeacher, d, 0)) {
    const si = items.findIndex((_, i) => dayQ[i] > 0 && queues[i].includes(fpTeacher))
    if (si >= 0) {
      const qi = queues[si].indexOf(fpTeacher)
      queues[si].splice(qi, 1)
      slots[0] = { subjectId: items[si].subjectId, teacherId: fpTeacher }
      dayQ[si]--
      if (items[si].block && dayQ[si] > 0 && !slots[1] && hasFree(si, 1)) place(si, 1)
    }
  }

  // 3) block subjects → adjacent pairs (never two separate periods in a day).
  //    An odd leftover (a day that needs just 1) is placed as a lone single.
  items.forEach((it, si) => {
    if (!it.block) return
    while (dayQ[si] >= 2) {
      let placed = false
      for (let p = 0; p < P - 1; p++) {
        if (breaks.has(p + 1)) continue
        if (
          !slots[p] && !slots[p + 1] &&
          !slotBlocked(si, p) && !slotBlocked(si, p + 1) &&
          hasFree(si, p) && hasFree(si, p + 1)
        ) {
          place(si, p)
          place(si, p + 1)
          placed = true
          break
        }
      }
      if (!placed) break
    }
    // single leftover (this day only needs one) — fine to place alone
    if (dayQ[si] === 1) {
      for (let p = 0; p < P; p++)
        if (!slots[p] && !slotBlocked(si, p) && hasFree(si, p)) {
          place(si, p)
          break
        }
    }
    // if dayQ[si] is still >= 2 here, no adjacent pair could be formed — leave
    // those cells blank rather than splitting the block into separate periods.
  })

  // 4) non-block subjects as singles — PE-group first so they grab a
  //    non-blocked slot before the rest of the day fills up.
  const order = items.map((_, si) => si).sort((a, b) => (isPe(b) ? 1 : 0) - (isPe(a) ? 1 : 0))
  for (const si of order) {
    if (items[si].block) continue // block subjects handled above (pairs only)
    while (dayQ[si] > 0) {
      let placed = false
      for (let p = 0; p < P; p++)
        if (!slots[p] && !slotBlocked(si, p) && hasFree(si, p)) {
          place(si, p)
          placed = true
          break
        }
      if (!placed) break
    }
  }
}

function __unusedLegacyAutoGen(
  state: AppState,
  classId: string,
  opts: { classTeacherFirstPeriod: boolean; overwrite: boolean; extraBusy?: Set<string> },
): ClassGrid {
  const cls = findClass(state, classId)
  const cfg = state.classSubjects.find((c) => c.classId === classId)
  const periods = state.settings.periodsPerDay
  if (!cls || !cfg) return emptyGrid(periods)

  const extraBusy = opts.extraBusy ?? new Set<string>()
  const busyAt = (tid: string, d: Day, p: number) =>
    isTeacherBusy(state, tid, d, p, classId) || extraBusy.has(`${tid}|${d}|${p}`)

  const existing = state.timetables.find((t) => t.classId === classId)
  // overwrite ON => preserve existing periods & fill gaps; OFF => rebuild fresh.
  const grid: ClassGrid =
    opts.overwrite && existing ? cloneGrid(existing.grid) : emptyGrid(periods)

  // Build placement units with a teacher per period (supports multi-teacher).
  const units: PlaceUnit[] = []
  for (const it of cfg.items) {
    const queue = teacherQueueFor(state, cls, it)
    // Account for periods already in the grid (overwrite-preserve) per teacher.
    for (const sl of allSlotsOfSubject(grid, it.subjectId)) {
      const idx = queue.indexOf(sl.teacherId)
      if (idx >= 0) queue.splice(idx, 1)
      else if (queue.length) queue.pop()
    }
    for (const tid of queue) units.push({ subjectId: it.subjectId, block: it.block, teacherId: tid })
  }
  units.sort((a, b) => unitWeight(cfg, b.subjectId) - unitWeight(cfg, a.subjectId))

  // Step 0: place subjects pinned to a fixed day/period (e.g. CLA block).
  for (const it of cfg.items) {
    if (it.fixedDay && it.fixedStartPeriod != null) {
      const span = it.block ? 2 : 1
      for (let k = 0; k < span; k++) {
        const p = it.fixedStartPeriod + k
        if (p >= periods) break
        const u = units.find((x) => x.subjectId === it.subjectId)
        if (!u) break
        if (grid[it.fixedDay][p]) continue
        if (u.teacherId && busyAt(u.teacherId, it.fixedDay, p)) continue
        grid[it.fixedDay][p] = { subjectId: it.subjectId, teacherId: u.teacherId }
        removeExactUnit(units, it.subjectId, u.teacherId)
      }
    }
  }

  // Step 1: seat the first-period teacher in period 1 every day, using their
  // highest-period subject in this class (a single; daily/block steps extend it).
  const fpTeacher = cls.firstPeriodTeacherId || (opts.classTeacherFirstPeriod ? cls.classTeacherId : undefined)
  if (fpTeacher) {
    const fpSubjectIds = [...cfg.items]
      .sort((a, b) => b.periodsPerWeek - a.periodsPerWeek)
      .map((i) => i.subjectId)
    for (const d of DAYS) {
      if (grid[d][0]) continue
      if (busyAt(fpTeacher, d, 0)) continue
      const sid = fpSubjectIds.find((s) => units.some((u) => u.subjectId === s && u.teacherId === fpTeacher))
      if (!sid) break
      grid[d][0] = { subjectId: sid, teacherId: fpTeacher }
      removeExactUnit(units, sid, fpTeacher)
    }
  }

  // Step 1.5: main subjects — distribute so they appear every working day,
  // doubling up (consecutive block where flagged) on the days that need extra.
  for (const it of cfg.items) {
    if (it.main) placeMainSubject(state, grid, classId, it.subjectId, it.block, busyAt, units)
  }

  // Step 2: place block subjects as same-teacher consecutive pairs.
  for (const it of cfg.items) {
    if (!it.block) continue
    let guard = 0
    while (guard++ < 50) {
      const tid = pairTeacher(units, it.subjectId)
      if (tid === null) break
      if (placeBlock(state, grid, classId, it.subjectId, tid, busyAt)) {
        removeExactUnit(units, it.subjectId, tid)
        removeExactUnit(units, it.subjectId, tid)
      } else break
    }
  }

  // Step 3: place remaining single units.
  for (const u of [...units]) {
    if (placeSingle(state, grid, classId, u.subjectId, u.teacherId, busyAt, u.block)) {
      removeExactUnit(units, u.subjectId, u.teacherId)
    }
  }

  // Step 4: repair — reshuffle so every required period is placed and no cell
  // is left empty (subject to the per-day caps and teacher availability).
  fillAndRepair(state, grid, classId, cfg, units, busyAt, fpTeacher)

  // Step 5: guarantee the first-period teacher actually sits in period 1 each day.
  if (fpTeacher) enforceFirstPeriod(state, grid, classId, fpTeacher, busyAt)

  return grid
}

function claId(state: AppState): string {
  return state.subjects.find((s) => s.acronym === 'CLA')?.id ?? '__cla__'
}

function unitWeight(cfg: { items: { subjectId: string; periodsPerWeek: number }[] }, sid: string) {
  return cfg.items.find((i) => i.subjectId === sid)?.periodsPerWeek ?? 0
}

function countSubjectInGrid(grid: ClassGrid, subjectId: string): number {
  let n = 0
  for (const d of DAYS) for (const s of grid[d]) if (s?.subjectId === subjectId) n++
  return n
}
function countSubjectInDay(grid: ClassGrid, d: Day, subjectId: string): number {
  return grid[d].filter((s) => s?.subjectId === subjectId).length
}

function removeUnit(units: PlaceUnit[], subjectId: string) {
  const idx = units.findIndex((u) => u.subjectId === subjectId)
  if (idx >= 0) units.splice(idx, 1)
}

/** Remove one unit matching both subject and teacher (falls back to subject). */
function removeExactUnit(units: PlaceUnit[], subjectId: string, teacherId: string) {
  let idx = units.findIndex((u) => u.subjectId === subjectId && u.teacherId === teacherId)
  if (idx < 0) idx = units.findIndex((u) => u.subjectId === subjectId)
  if (idx >= 0) units.splice(idx, 1)
}

/** A teacher who still has >= 2 units for the subject (for same-teacher blocks). */
function pairTeacher(units: PlaceUnit[], subjectId: string): string | null {
  const counts: Record<string, number> = {}
  for (const u of units) if (u.subjectId === subjectId) counts[u.teacherId] = (counts[u.teacherId] ?? 0) + 1
  for (const [tid, n] of Object.entries(counts)) if (n >= 2) return tid
  return null
}

/** All placed slots of a subject in the grid (with their teacher). */
function allSlotsOfSubject(grid: ClassGrid, subjectId: string): Slot[] {
  const out: Slot[] = []
  for (const d of DAYS) for (const s of grid[d]) if (s?.subjectId === subjectId) out.push(s)
  return out
}

function countUnit(units: PlaceUnit[], subjectId: string): number {
  return units.filter((u) => u.subjectId === subjectId).length
}

/** Recess boundary lies between index (recessAfter-1) and recessAfter. */
function crossesRecess(state: AppState, a: number, b: number): boolean {
  const lo = Math.min(a, b)
  // boundary sits after period number (lo+1) in 1-based terms
  return breakAfterSet(state.settings).has(lo + 1)
}

/** For a block subject already present once on a day, a second period must sit
 *  immediately next to it (and not across the recess). */
function adjacentOk(state: AppState, grid: ClassGrid, subjectId: string, d: Day, p: number): boolean {
  const periods = state.settings.periodsPerDay
  let existing = -1
  for (let i = 0; i < periods; i++)
    if (grid[d][i]?.subjectId === subjectId) {
      existing = i
      break
    }
  if (existing < 0) return true
  if (Math.abs(existing - p) !== 1) return false
  return !crossesRecess(state, existing, p)
}

/** Whether subject S may occupy (d,p): respects per-day cap and block adjacency. */
function dayAllows(
  state: AppState,
  grid: ClassGrid,
  subjectId: string,
  d: Day,
  p: number,
  block: boolean,
): boolean {
  const cnt = countSubjectInDay(grid, d, subjectId)
  if (cnt >= (block ? 2 : 1)) return false
  if (block && cnt === 1) return adjacentOk(state, grid, subjectId, d, p)
  return true
}

/** Place one period of a subject on a specific day. When preferAdjacent is set,
 *  it tries to sit next to an existing period of the same subject (forming a block). */
function placeUnitOnDay(
  state: AppState,
  grid: ClassGrid,
  classId: string,
  subjectId: string,
  teacherId: string,
  busyAt: (tid: string, d: Day, p: number) => boolean,
  d: Day,
  preferAdjacent: boolean,
): boolean {
  const periods = state.settings.periodsPerDay
  const cnt = countSubjectInDay(grid, d, subjectId)
  const maxPerDay = preferAdjacent ? 2 : 1
  if (cnt >= maxPerDay) return false
  // Block subject's 2nd period must be adjacent to the first.
  if (preferAdjacent && cnt === 1) {
    for (let i = 0; i < periods; i++) {
      if (grid[d][i]?.subjectId !== subjectId) continue
      for (const j of [i + 1, i - 1]) {
        if (j < 0 || j >= periods) continue
        if (crossesRecess(state, i, j)) continue
        if (canPlace(state, grid, classId, d, j, teacherId, busyAt)) {
          grid[d][j] = { subjectId, teacherId }
          return true
        }
      }
    }
    return false
  }
  // First (or only) period of this subject on the day: any free slot.
  for (let p = 0; p < periods; p++) {
    if (canPlace(state, grid, classId, d, p, teacherId, busyAt)) {
      grid[d][p] = { subjectId, teacherId }
      return true
    }
  }
  return false
}

/** Distribute a main subject across all working days (daily presence), doubling
 *  up on the days that need extra periods (consecutive block where flagged). */
function placeMainSubject(
  state: AppState,
  grid: ClassGrid,
  classId: string,
  subjectId: string,
  block: boolean,
  busyAt: (tid: string, d: Day, p: number) => boolean,
  units: PlaceUnit[],
): void {
  const total = countUnit(units, subjectId)
  if (total <= 0) return
  const D = DAYS.length
  const existing = DAYS.map((d) => countSubjectInDay(grid, d, subjectId))
  const add = DAYS.map(() => 0)
  // Even out: give each extra period to the day with the fewest of this subject.
  for (let k = 0; k < total; k++) {
    let best = 0
    for (let i = 1; i < D; i++) if (existing[i] + add[i] < existing[best] + add[best]) best = i
    add[best]++
  }
  for (let i = 0; i < D; i++) {
    let need = add[i]
    while (need > 0) {
      const u = units.find((x) => x.subjectId === subjectId)
      if (!u) return
      const ok = placeUnitOnDay(state, grid, classId, subjectId, u.teacherId, busyAt, DAYS[i], block)
      if (!ok) break
      removeExactUnit(units, subjectId, u.teacherId)
      need--
    }
  }
}

/**
 * Repair pass: guarantees every required period is placed (and thus every cell
 * filled when the configured periods sum to capacity). For each still-short
 * subject it finds a day with spare capacity; if that day is full it relocates
 * another period to an empty cell elsewhere to make room.
 */
function fillAndRepair(
  state: AppState,
  grid: ClassGrid,
  classId: string,
  cfg: { items: { subjectId: string; periodsPerWeek: number; block?: boolean }[] },
  units: PlaceUnit[],
  busyAt: (tid: string, d: Day, p: number) => boolean,
  fpTeacher?: string,
): void {
  const periods = state.settings.periodsPerDay
  const maxDay = (sid: string) => (cfg.items.find((i) => i.subjectId === sid)?.block ? 2 : 1)
  const isBlock = (sid: string) => !!cfg.items.find((i) => i.subjectId === sid)?.block
  const teacherFree = (tid: string, d: Day, p: number) => !tid || !busyAt(tid, d, p)
  // a still-pending unit of subject S whose teacher is free at (d,p)
  const unitFor = (sid: string, d: Day, p: number) =>
    units.find((u) => u.subjectId === sid && teacherFree(u.teacherId, d, p)) ?? null

  let guard = 0
  while (guard++ < 2000) {
    const needed = [...new Set(units.map((u) => u.subjectId))].sort(
      (a, b) => countUnit(units, b) - countUnit(units, a),
    )
    if (needed.length === 0) break

    let progressed = false
    for (const s of needed) {
      let placed = false
      const days = [...DAYS].sort((a, b) => countSubjectInDay(grid, a, s) - countSubjectInDay(grid, b, s))
      for (const d of days) {
        if (placed) break
        if (countSubjectInDay(grid, d, s) >= maxDay(s)) continue
        // 1) direct: an empty period on this day where a unit's teacher is free
        for (let p = 0; p < periods; p++) {
          if (grid[d][p]) continue
          if (!dayAllows(state, grid, s, d, p, isBlock(s))) continue
          const u = unitFor(s, d, p)
          if (u) {
            grid[d][p] = { subjectId: s, teacherId: u.teacherId }
            removeExactUnit(units, s, u.teacherId)
            placed = true
            break
          }
        }
        if (placed) break
        // 2) make room: lift a blocking period and move it to any valid empty
        //    cell (same day allowed), then place the short subject here.
        for (let p = 0; p < periods && !placed; p++) {
          const cell = grid[d][p]
          if (!cell || cell.subjectId === s) continue
          if (p === 0 && fpTeacher && cell.teacherId === fpTeacher) continue
          if (!dayAllows(state, grid, s, d, p, isBlock(s))) continue
          const u = unitFor(s, d, p)
          if (!u) continue
          const b = cell.subjectId
          grid[d][p] = null // tentatively lift the blocker
          let moved = false
          for (const de of DAYS) {
            if (moved) break
            for (let pe = 0; pe < periods; pe++) {
              if (grid[de][pe]) continue
              if (de === d && pe === p) continue
              if (!dayAllows(state, grid, b, de, pe, isBlock(b))) continue
              if (cell.teacherId && busyAt(cell.teacherId, de, pe)) continue
              grid[de][pe] = cell
              moved = true
              break
            }
          }
          if (moved) {
            grid[d][p] = { subjectId: s, teacherId: u.teacherId }
            removeExactUnit(units, s, u.teacherId)
            placed = true
          } else {
            grid[d][p] = cell // revert
          }
        }
      }
      if (placed) progressed = true
    }
    if (!progressed) break
  }
}

/**
 * Guarantee the first-period teacher occupies period 1 each day. If they are
 * teaching elsewhere that day, swap that period with P1 (preserves all counts).
 */
function enforceFirstPeriod(
  state: AppState,
  grid: ClassGrid,
  classId: string,
  fpTeacher: string,
  busyAt: (tid: string, d: Day, p: number) => boolean,
): void {
  const periods = state.settings.periodsPerDay
  const inBlock = (d: Day, p: number) => {
    const s = grid[d][p]?.subjectId
    if (!s) return false
    return grid[d][p - 1]?.subjectId === s || grid[d][p + 1]?.subjectId === s
  }
  for (const d of DAYS) {
    const cur = grid[d][0]
    if (cur && cur.teacherId === fpTeacher) continue
    // pick a single (non-block) period of the first-period teacher to move to P1
    let p1 = -1
    for (let p = 1; p < periods; p++) {
      if (grid[d][p]?.teacherId === fpTeacher && !inBlock(d, p)) {
        p1 = p
        break
      }
    }
    if (p1 < 0) continue
    if (busyAt(fpTeacher, d, 0)) continue
    // don't split a block that currently sits at P1
    if (cur && cur.teacherId && busyAt(cur.teacherId, d, p1)) continue
    if (cur && inBlock(d, 0)) continue
    grid[d][0] = grid[d][p1]
    grid[d][p1] = cur
  }
}

function cloneGrid(g: ClassGrid): ClassGrid {
  const out = {} as ClassGrid
  for (const d of DAYS) out[d] = g[d].map((s) => (s ? { ...s } : null))
  return out
}

function canPlace(
  state: AppState,
  grid: ClassGrid,
  classId: string,
  d: Day,
  p: number,
  teacherId: string,
  busyAt: (tid: string, d: Day, p: number) => boolean,
): boolean {
  if (grid[d][p]) return false
  if (teacherId && busyAt(teacherId, d, p)) return false
  return true
}

function placeSingle(
  state: AppState,
  grid: ClassGrid,
  classId: string,
  subjectId: string,
  teacherId: string,
  busyAt: (tid: string, d: Day, p: number) => boolean,
  block: boolean,
): boolean {
  const maxPerDay = block ? 2 : 1
  // Prefer days that don't already have this subject.
  const days = [...DAYS].sort(
    (a, b) => countSubjectInDay(grid, a, subjectId) - countSubjectInDay(grid, b, subjectId),
  )
  const periods = state.settings.periodsPerDay
  for (const d of days) {
    if (countSubjectInDay(grid, d, subjectId) >= maxPerDay) continue
    for (let p = 0; p < periods; p++) {
      if (!dayAllows(state, grid, subjectId, d, p, block)) continue
      if (canPlace(state, grid, classId, d, p, teacherId, busyAt)) {
        grid[d][p] = { subjectId, teacherId }
        return true
      }
    }
  }
  return false
}

function placeBlock(
  state: AppState,
  grid: ClassGrid,
  classId: string,
  subjectId: string,
  teacherId: string,
  busyAt: (tid: string, d: Day, p: number) => boolean,
): boolean {
  const periods = state.settings.periodsPerDay
  const recessAfter = state.settings.recessAfterPeriod // 1-based
  const days = [...DAYS].sort(
    (a, b) => countSubjectInDay(grid, a, subjectId) - countSubjectInDay(grid, b, subjectId),
  )
  for (const d of days) {
    if (countSubjectInDay(grid, d, subjectId) > 0) continue
    for (let p = 0; p < periods - 1; p++) {
      // Don't straddle the recess boundary.
      if (p + 1 === recessAfter) continue
      if (
        canPlace(state, grid, classId, d, p, teacherId, busyAt) &&
        canPlace(state, grid, classId, d, p + 1, teacherId, busyAt)
      ) {
        grid[d][p] = { subjectId, teacherId }
        grid[d][p + 1] = { subjectId, teacherId }
        return true
      }
    }
  }
  // No consecutive pair available — leave it for single placement (Step 3).
  return false
}
