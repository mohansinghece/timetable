import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { AppState } from '../types'
import { loadState, saveState as saveLocal } from '../lib/storage'
import { seedState } from '../lib/seed'
import { apiLogin, fetchState, getToken, pushState, setToken } from '../lib/api'

export type SyncStatus = 'loading' | 'online' | 'saving' | 'saved' | 'error' | 'offline' | 'unsaved'

interface Ctx {
  state: AppState
  ready: boolean
  sync: SyncStatus
  update: (mutator: (draft: AppState) => void) => void
  replace: (next: AppState) => void
  reset: () => void
  isAdmin: boolean
  login: (password: string) => Promise<boolean>
  logout: () => void
  saveNow: () => Promise<void>
  refresh: () => Promise<void>
  // history
  undo: () => void
  redo: () => void
  canUndo: boolean
  canRedo: boolean
  // auto-save preference
  autoSave: boolean
  setAutoSave: (v: boolean) => void
}

const AppCtx = createContext<Ctx | null>(null)
const MAX_HISTORY = 60

function clone<T>(v: T): T {
  if (typeof structuredClone === 'function') return structuredClone(v)
  return JSON.parse(JSON.stringify(v))
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(() => loadState())
  const [ready, setReady] = useState(false)
  const [sync, setSync] = useState<SyncStatus>('loading')
  const [isAdmin, setIsAdmin] = useState<boolean>(() => !!getToken())
  const [past, setPast] = useState<AppState[]>([])
  const [future, setFuture] = useState<AppState[]>([])
  const [autoSave, setAutoSaveState] = useState<boolean>(
    () => localStorage.getItem('kv-autosave') !== '0',
  )

  const stateRef = useRef(state)
  stateRef.current = state
  const autoSaveRef = useRef(autoSave)
  autoSaveRef.current = autoSave
  const pushTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    fetchState()
      .then((remote) => {
        if (remote) {
          const merged = { ...seedState(), ...remote }
          setState(merged)
          saveLocal(merged)
        }
        setSync('online')
      })
      .catch(() => setSync('offline'))
      .finally(() => setReady(true))
  }, [])

  const refresh = useCallback(async () => {
    try {
      const remote = await fetchState()
      if (remote) {
        const merged = { ...seedState(), ...remote }
        setState(merged)
        saveLocal(merged)
      }
      setSync('online')
    } catch {
      setSync('offline')
    }
  }, [])

  const doPush = useCallback(async () => {
    const token = getToken()
    if (!token) return
    setSync('saving')
    try {
      const ok = await pushState(stateRef.current, token)
      setSync(ok ? 'saved' : 'error')
    } catch {
      setSync('error')
    }
  }, [])

  const schedulePush = useCallback(() => {
    if (!getToken()) return
    if (!autoSaveRef.current) {
      setSync('unsaved')
      return
    }
    if (pushTimer.current) clearTimeout(pushTimer.current)
    pushTimer.current = setTimeout(doPush, 700)
  }, [doPush])

  /** Apply a brand-new state, recording the previous one for undo. */
  const commit = useCallback(
    (next: AppState, record = true) => {
      if (record) {
        setPast((p) => [...p.slice(-(MAX_HISTORY - 1)), stateRef.current])
        setFuture([])
      }
      setState(next)
      saveLocal(next)
      schedulePush()
    },
    [schedulePush],
  )

  const update = useCallback(
    (mutator: (draft: AppState) => void) => {
      const draft = clone(stateRef.current)
      mutator(draft)
      commit(draft)
    },
    [commit],
  )

  const replace = useCallback((next: AppState) => commit(next), [commit])
  const reset = useCallback(() => commit(seedState()), [commit])

  const undo = useCallback(() => {
    setPast((p) => {
      if (p.length === 0) return p
      const prev = p[p.length - 1]
      setFuture((f) => [stateRef.current, ...f].slice(0, MAX_HISTORY))
      setState(prev)
      saveLocal(prev)
      schedulePush()
      return p.slice(0, -1)
    })
  }, [schedulePush])

  const redo = useCallback(() => {
    setFuture((f) => {
      if (f.length === 0) return f
      const nxt = f[0]
      setPast((p) => [...p.slice(-(MAX_HISTORY - 1)), stateRef.current])
      setState(nxt)
      saveLocal(nxt)
      schedulePush()
      return f.slice(1)
    })
  }, [schedulePush])

  const setAutoSave = useCallback(
    (v: boolean) => {
      setAutoSaveState(v)
      localStorage.setItem('kv-autosave', v ? '1' : '0')
      if (v) schedulePush()
    },
    [schedulePush],
  )

  const login = useCallback(async (password: string) => {
    const token = await apiLogin(password)
    if (token) {
      setToken(token)
      setIsAdmin(true)
      return true
    }
    if (password === stateRef.current.settings.adminPassword) {
      setToken(password)
      setIsAdmin(true)
      return true
    }
    return false
  }, [])

  const logout = useCallback(() => {
    setToken(null)
    setIsAdmin(false)
  }, [])

  const saveNow = useCallback(async () => {
    if (pushTimer.current) clearTimeout(pushTimer.current)
    await doPush()
  }, [doPush])

  const value = useMemo<Ctx>(
    () => ({
      state, ready, sync, update, replace, reset, isAdmin, login, logout, saveNow, refresh,
      undo, redo, canUndo: past.length > 0, canRedo: future.length > 0, autoSave, setAutoSave,
    }),
    [state, ready, sync, update, replace, reset, isAdmin, login, logout, saveNow, refresh, undo, redo, past.length, future.length, autoSave, setAutoSave],
  )

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>
}

export function useApp() {
  const ctx = useContext(AppCtx)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
