import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export function Card({
  children,
  className = '',
}: {
  children: React.ReactNode
  className?: string
}) {
  return <div className={`card p-4 ${className}`}>{children}</div>
}

export function SectionTitle({
  icon,
  title,
  subtitle,
  right,
}: {
  icon?: React.ReactNode
  title: string
  subtitle?: string
  right?: React.ReactNode
}) {
  return (
    <div className="flex items-center justify-between gap-3 mb-3">
      <div className="flex items-center gap-2.5 min-w-0">
        {icon && <span className="text-xl shrink-0">{icon}</span>}
        <div className="min-w-0">
          <h2 className="font-bold text-slate-800 leading-tight truncate">{title}</h2>
          {subtitle && <p className="text-xs text-slate-500 truncate">{subtitle}</p>}
        </div>
      </div>
      {right}
    </div>
  )
}

export function Modal({
  open,
  onClose,
  title,
  icon,
  children,
  footer,
  maxWidth = 'max-w-lg',
}: {
  open: boolean
  onClose: () => void
  title: string
  icon?: React.ReactNode
  children: React.ReactNode
  footer?: React.ReactNode
  maxWidth?: string
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose} />
      <div
        className={`relative w-full ${maxWidth} bg-white rounded-t-3xl sm:rounded-3xl shadow-xl max-h-[92vh] flex flex-col animate-[slideup_.2s_ease]`}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2 font-bold text-slate-800">
            {icon && <span className="text-lg">{icon}</span>}
            {title}
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 text-xl px-2">
            ✕
          </button>
        </div>
        <div className="overflow-y-auto px-5 py-4 grow">{children}</div>
        {footer && <div className="px-5 py-3 border-t border-slate-100">{footer}</div>}
      </div>
      <style>{`@keyframes slideup{from{transform:translateY(16px);opacity:.6}to{transform:translateY(0);opacity:1}}`}</style>
    </div>
  )
}

export function ProgressBar({
  value,
  total,
  color = 'bg-brand-600',
}: {
  value: number
  total: number
  color?: string
}) {
  const pct = total > 0 ? Math.round((value / total) * 100) : 0
  return (
    <div className="w-full">
      <div className="h-2.5 w-full rounded-full bg-slate-100 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${color}`}
          style={{ width: `${Math.min(100, pct)}%` }}
        />
      </div>
    </div>
  )
}

export function Empty({ icon = '📭', text }: { icon?: string; text: string }) {
  return (
    <div className="text-center py-10 text-slate-400">
      <div className="text-4xl mb-2">{icon}</div>
      <p className="text-sm">{text}</p>
    </div>
  )
}

export function StatCard({
  label,
  value,
  hint,
  accent = 'bg-brand-600',
}: {
  label: string
  value: React.ReactNode
  hint?: string
  accent?: string
}) {
  return (
    <div className="card overflow-hidden">
      <div className={`h-1.5 ${accent}`} />
      <div className="p-3.5">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</p>
        <p className="text-2xl font-extrabold text-slate-800 leading-tight mt-1">{value}</p>
        {hint && <p className="text-[11px] text-slate-400 mt-0.5">{hint}</p>}
      </div>
    </div>
  )
}

export function PageHeader({
  title,
  back = '/config',
  right,
}: {
  title: string
  back?: string
  right?: React.ReactNode
}) {
  const navigate = useNavigate()
  return (
    <div className="flex items-center justify-between gap-2 mb-4">
      <div className="flex items-center gap-2 min-w-0">
        <button
          onClick={() => navigate(back)}
          className="h-9 w-9 grid place-items-center rounded-xl bg-white border border-slate-200 text-slate-600 shrink-0 text-lg"
        >
          ‹
        </button>
        <h1 className="text-lg font-extrabold text-slate-800 truncate">{title}</h1>
      </div>
      {right}
    </div>
  )
}
