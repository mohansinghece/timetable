import { useApp } from '../../store/AppContext'
import { Card, Empty, PageHeader } from '../../components/ui'
import { className } from '../../lib/timetable'

export default function ClassTeachers() {
  const { state, update } = useApp()

  const patchClass = (classId: string, fn: (c: any) => void) =>
    update((d) => {
      const c = d.classes.find((x) => x.id === classId)
      if (c) fn(c)
    })

  return (
    <div>
      <PageHeader title="Class Teachers" />
      {state.teachers.length === 0 ? (
        <Empty icon="⭐" text="Add teachers first in Setup → Teachers." />
      ) : (
        <div className="space-y-2">
          {state.classes.map((c) => (
            <Card key={c.id}>
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-slate-800">Class {className(c)}</span>
              </div>
              <div className="grid grid-cols-1 gap-2">
                <div>
                  <label className="label">Class Teacher</label>
                  <select
                    className="input"
                    value={c.classTeacherId ?? ''}
                    onChange={(e) =>
                      patchClass(c.id, (x) => {
                        x.classTeacherId = e.target.value || undefined
                        // default the first-period teacher to the class teacher
                        if (!x.firstPeriodTeacherId) x.firstPeriodTeacherId = e.target.value || undefined
                      })
                    }
                  >
                    <option value="">— none —</option>
                    {state.teachers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Co-Class Teacher</label>
                  <select
                    className="input"
                    value={c.coClassTeacherId ?? ''}
                    onChange={(e) => patchClass(c.id, (x) => (x.coClassTeacherId = e.target.value || undefined))}
                  >
                    <option value="">— none —</option>
                    {state.teachers
                      .filter((t) => t.id !== c.classTeacherId)
                      .map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name}
                        </option>
                      ))}
                  </select>
                </div>

                <div className="rounded-xl bg-brand-50/60 p-3 space-y-2">
                  <label className="label mb-0">First-period teacher</label>
                  <select
                    className="input"
                    value={c.firstPeriodTeacherId ?? ''}
                    onChange={(e) => patchClass(c.id, (x) => (x.firstPeriodTeacherId = e.target.value || undefined))}
                  >
                    <option value="">— class teacher / auto —</option>
                    {state.teachers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
