import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import Layout from './components/Layout'
import { useApp } from './store/AppContext'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import ConfigHub from './pages/config/ConfigHub'
import Classes from './pages/config/Classes'
import Teachers from './pages/config/Teachers'
import Posts from './pages/config/Posts'
import Subjects from './pages/config/Subjects'
import ClassTeachers from './pages/config/ClassTeachers'
import ClassSubjects from './pages/config/ClassSubjects'
import Timings from './pages/config/Timings'
import TimetableHub from './pages/timetable/TimetableHub'
import ManualEditor from './pages/timetable/ManualEditor'
import AutoGenerate from './pages/timetable/AutoGenerate'
import Views from './pages/views/Views'
import Arrangement from './pages/Arrangement'
import Settings from './pages/Settings'

function AdminOnly({ children }: { children: JSX.Element }) {
  const { isAdmin } = useApp()
  const loc = useLocation()
  if (!isAdmin) return <Navigate to="/login" replace state={{ from: loc.pathname }} />
  return children
}

export default function App() {
  const { ready, isAdmin } = useApp()

  if (!ready) {
    return (
      <div className="min-h-screen grid place-items-center bg-slate-100">
        <div className="text-center">
          <div className="h-12 w-12 rounded-2xl bg-brand-700 grid place-items-center text-2xl mx-auto mb-3 animate-pulse">
            📘
          </div>
          <p className="text-sm text-slate-500">Loading timetable…</p>
        </div>
      </div>
    )
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      {/* Public (no login) */}
      <Route path="/" element={<Layout>{isAdmin ? <Dashboard /> : <Navigate to="/view" replace />}</Layout>} />
      <Route path="/view" element={<Layout><Views /></Layout>} />
      <Route path="/arrangement" element={<Layout><Arrangement /></Layout>} />

      {/* Admin only */}
      <Route path="/config" element={<Layout><AdminOnly><ConfigHub /></AdminOnly></Layout>} />
      <Route path="/config/classes" element={<Layout><AdminOnly><Classes /></AdminOnly></Layout>} />
      <Route path="/config/teachers" element={<Layout><AdminOnly><Teachers /></AdminOnly></Layout>} />
      <Route path="/config/posts" element={<Layout><AdminOnly><Posts /></AdminOnly></Layout>} />
      <Route path="/config/subjects" element={<Layout><AdminOnly><Subjects /></AdminOnly></Layout>} />
      <Route path="/config/class-teachers" element={<Layout><AdminOnly><ClassTeachers /></AdminOnly></Layout>} />
      <Route path="/config/class-subjects" element={<Layout><AdminOnly><ClassSubjects /></AdminOnly></Layout>} />
      <Route path="/config/timings" element={<Layout><AdminOnly><Timings /></AdminOnly></Layout>} />
      <Route path="/timetable" element={<Layout><AdminOnly><TimetableHub /></AdminOnly></Layout>} />
      <Route path="/timetable/manual" element={<Layout><AdminOnly><ManualEditor /></AdminOnly></Layout>} />
      <Route path="/timetable/build/:classId" element={<Layout><AdminOnly><ManualEditor /></AdminOnly></Layout>} />
      <Route path="/timetable/auto" element={<Layout><AdminOnly><AutoGenerate /></AdminOnly></Layout>} />
      <Route path="/settings" element={<Layout><AdminOnly><Settings /></AdminOnly></Layout>} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
