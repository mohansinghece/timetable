import { useMemo, useState } from 'react'
import { useApp } from '../../store/AppContext'
import { Card, Empty, Modal, PageHeader } from '../../components/ui'
import { uid } from '../../lib/seed'
import { Teacher } from '../../types'

export default function Teachers() {
  const { state, update } = useApp()
  const [open, setOpen] = useState(false)
  const [edit, setEdit] = useState<Teacher | null>(null)
  const [name, setName] = useState('')
  const [acronym, setAcronym] = useState('')
  const [postId, setPostId] = useState(state.posts[0]?.id ?? '')
  const [q, setQ] = useState('')

  const postCode = (id: string) => state.posts.find((p) => p.id === id)?.code ?? '?'

  const start = (t?: Teacher) => {
    setEdit(t ?? null)
    setName(t?.name ?? '')
    setAcronym(t?.acronym ?? '')
    setPostId(t?.postId ?? state.posts[0]?.id ?? '')
    setOpen(true)
  }

  const save = () => {
    if (!name.trim() || !postId) return
    update((d) => {
      if (edit) {
        const t = d.teachers.find((x) => x.id === edit.id)
        if (t) {
          t.name = name.trim()
          t.acronym = acronym.trim().toUpperCase()
          t.postId = postId
        }
      } else {
        d.teachers.push({
          id: uid(),
          name: name.trim(),
          acronym: acronym.trim().toUpperCase(),
          postId,
        })
      }
    })
    setOpen(false)
  }

  const remove = (t: Teacher) => {
    if (!confirm(`Delete teacher "${t.name}"? Their timetable slots will be cleared.`)) return
    update((d) => {
      d.teachers = d.teachers.filter((x) => x.id !== t.id)
      d.classes.forEach((c) => {
        if (c.classTeacherId === t.id) c.classTeacherId = undefined
        if (c.coClassTeacherId === t.id) c.coClassTeacherId = undefined
        if (c.firstPeriodTeacherId === t.id) c.firstPeriodTeacherId = undefined
      })
      d.classSubjects.forEach((cs) =>
        cs.items.forEach((it) => {
          if (it.teacherId === t.id) it.teacherId = undefined
        }),
      )
      d.timetables.forEach((tt) => {
        Object.values(tt.grid).forEach((row) =>
          row.forEach((slot) => {
            if (slot && slot.teacherId === t.id) slot.teacherId = ''
          }),
        )
      })
    })
  }

  const filtered = useMemo(
    () => state.teachers.filter((t) => t.name.toLowerCase().includes(q.toLowerCase())),
    [state.teachers, q],
  )

  return (
    <div>
      <PageHeader
        title="Teachers"
        right={
          <button onClick={() => start()} className="btn-primary text-xs">
            + Add
          </button>
        }
      />
      {state.teachers.length > 0 && (
        <input
          className="input mb-3"
          placeholder="Search teacher…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      )}
      {state.teachers.length === 0 ? (
        <Empty icon="👩‍🏫" text="No teachers yet. Add your staff." />
      ) : (
        <div className="space-y-2">
          {filtered.map((t) => (
            <Card key={t.id} className="flex items-center gap-3">
              <div className="grow min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-slate-800 truncate">{t.name}</span>
                  {t.acronym && (
                    <span className="chip bg-accent-50 text-accent-700 shrink-0">{t.acronym}</span>
                  )}
                  <span className="chip bg-brand-50 text-brand-700 shrink-0">{postCode(t.postId)}</span>
                </div>
              </div>
              <button onClick={() => start(t)} className="text-slate-400 px-2">✏️</button>
              <button onClick={() => remove(t)} className="text-red-400 px-2">🗑️</button>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={edit ? 'Edit Teacher' : 'Add Teacher'}
        icon="👩‍🏫"
        footer={
          <button onClick={save} className="btn-primary w-full">
            Save
          </button>
        }
      >
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <label className="label">Teacher name</label>
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Mr. Mohan Singh" />
            </div>
            <div>
              <label className="label">Acronym</label>
              <input
                className="input uppercase"
                value={acronym}
                maxLength={6}
                onChange={(e) => setAcronym(e.target.value)}
                placeholder="MS"
              />
            </div>
          </div>
          <p className="-mt-2 text-[11px] text-slate-400">
            Acronym shows inside timetable cells. Assign which subject a teacher takes in each class
            from <b>Subjects per Class</b>.
          </p>

          <div>
            <label className="label">Post / Designation</label>
            <div className="flex flex-wrap gap-2">
              {state.posts.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setPostId(p.id)}
                  className={`chip border ${
                    postId === p.id
                      ? 'bg-brand-700 text-white border-brand-700'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  {p.code}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Modal>
    </div>
  )
}
