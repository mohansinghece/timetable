import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useApp } from '../../store/AppContext'
import { Card, Modal, PageHeader } from '../../components/ui'
import SubjectTally from '../../components/SubjectTally'
import { DAYS, DAY_LABELS, Day, Slot } from '../../types'
import {
  className,
  classProgress,
  emptyGrid,
  findSubject,
  findTeacher,
  getTimetable,
  isCommonBusy,
  pendingForClass,
  postCode,
  teacherSlot,
  teacherWeek,
  teacherWorkload,
  cellSubject,
} from '../../lib/timetable'

type Mode = 'day' | 'class' | 'teacher'

export default function ManualEditor() {
  const { classId: routeClassId } = useParams()
  const { state, update } = useApp()
  const periods = state.settings.periodsPerDay

  const [mode, setMode] = useState<Mode>(routeClassId ? 'class' : 'day')
  const [classId, setClassId] = useState(routeClassId || state.classes[0]?.id || '')
  const [teacherId, setTeacherId] = useState(state.teachers[0]?.id || '')
  const [day, setDay] = useState<Day>('MON')

  // class-cell editor target
  const [classEdit, setClassEdit] = useState<{ day: Day; p: number } | null>(null)
  // teacher-cell editor target (teacher fixed)
  const [teacherEdit, setTeacherEdit] = useState<{ teacherId: string; day: Day; p: number } | null>(null)

  /** Set a class slot, freeing the assigned teacher from other classes at the same time. */
  const setClassSlot = (cid: string, d0: Day, p: number, slot: Slot | null) =>
    update((d) => {
      let tt = d.timetables.find((t) => t.classId === cid)
      if (!tt) {
        tt = { classId: cid, grid: emptyGrid(d.settings.periodsPerDay) }
        d.timetables.push(tt)
      }
      if (slot?.teacherId) {
        for (const o of d.timetables) {
          if (o.classId === cid) continue
          const s = o.grid[d0]?.[p]
          if (s && s.teacherId === slot.teacherId) o.grid[d0][p] = null
        }
      }
      tt.grid[d0][p] = slot
    })

  const resetDay = (d0: Day) => {
    if (!confirm(`Reset the entire ${DAY_LABELS[d0]} timetable for all classes?`)) return
    update((d) => {
      for (const tt of d.timetables) tt.grid[d0] = Array.from({ length: d.settings.periodsPerDay }, () => null)
    })
  }
  const resetClass = (cid: string) => {
    const c = state.classes.find((x) => x.id === cid)
    if (!confirm(`Reset the whole timetable for Class ${c ? className(c) : ''}?`)) return
    update((d) => {
      const tt = d.timetables.find((t) => t.classId === cid)
      if (tt) tt.grid = emptyGrid(d.settings.periodsPerDay)
    })
  }
  const resetTeacher = (tid: string) => {
    const t = findTeacher(state, tid)
    if (!confirm(`Clear all periods assigned to ${t?.name ?? 'this teacher'} this week?`)) return
    update((d) => {
      for (const tt of d.timetables)
        for (const dd of DAYS)
          tt.grid[dd]?.forEach((s, i) => {
            if (s && s.teacherId === tid) tt.grid[dd][i] = null
          })
    })
  }

  return (
    <div>
      <PageHeader title="Manual Timetable" back="/timetable" />

      <div className="grid grid-cols-3 gap-2 mb-3">
        {(['day', 'class', 'teacher'] as Mode[]).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={`rounded-xl py-2.5 text-sm font-bold border capitalize ${
              mode === m ? 'bg-brand-700 text-white border-brand-700' : 'bg-white text-slate-600 border-slate-200'
            }`}
          >
            {m}-wise
          </button>
        ))}
      </div>

      <Card className="mb-3">
        {mode === 'class' && (
          <div className="flex items-center gap-2">
            <select className="input" value={classId} onChange={(e) => setClassId(e.target.value)}>
              {state.classes.map((c) => (
                <option key={c.id} value={c.id}>Class {className(c)}</option>
              ))}
            </select>
            <button onClick={() => resetClass(classId)} className="btn-danger text-xs shrink-0">↺ Reset</button>
          </div>
        )}
        {mode === 'teacher' && (
          <div className="flex items-center gap-2">
            <select className="input" value={teacherId} onChange={(e) => setTeacherId(e.target.value)}>
              {state.teachers.map((t) => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
            <button onClick={() => resetTeacher(teacherId)} className="btn-danger text-xs shrink-0">↺ Reset</button>
          </div>
        )}
        {mode === 'day' && (
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar grow">
              {DAYS.map((d) => (
                <button
                  key={d}
                  onClick={() => setDay(d)}
                  className={`px-3.5 py-2 rounded-xl text-sm font-bold shrink-0 ${
                    day === d ? 'bg-brand-700 text-white' : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
            <button onClick={() => resetDay(day)} className="btn-danger text-xs shrink-0">↺ Reset</button>
          </div>
        )}
        {mode === 'class' && <ClassMeta classId={classId} />}
        {mode === 'teacher' && <TeacherMeta teacherId={teacherId} />}
      </Card>

      {mode === 'class' && (
        <ClassGridEditor
          classId={classId}
          periods={periods}
          onCell={(d0, p) => setClassEdit({ day: d0, p })}
        />
      )}
      {mode === 'class' && (
        <div className="mt-3">
          <SubjectTally classId={classId} />
        </div>
      )}
      {mode === 'teacher' && (
        <TeacherGridEditor
          teacherId={teacherId}
          periods={periods}
          onCell={(d0, p) => setTeacherEdit({ teacherId, day: d0, p })}
        />
      )}
      {mode === 'day' && (
        <DayGridEditor
          day={day}
          periods={periods}
          onCell={(tid, p) => setTeacherEdit({ teacherId: tid, day, p })}
        />
      )}

      <ClassCellModal
        target={classEdit ? { classId, day: classEdit.day, p: classEdit.p } : null}
        onClose={() => setClassEdit(null)}
        onSave={(slot) => {
          if (classEdit) setClassSlot(classId, classEdit.day, classEdit.p, slot)
          setClassEdit(null)
        }}
      />
      <TeacherCellModal
        target={teacherEdit}
        onClose={() => setTeacherEdit(null)}
        onSave={(cid, slot) => {
          if (teacherEdit) {
            // clearing: remove teacher from wherever they are at this slot
            const cur = teacherSlot(state, teacherEdit.teacherId, teacherEdit.day, teacherEdit.p)
            if (!slot && cur) setClassSlot(cur.classId, teacherEdit.day, teacherEdit.p, null)
            else if (slot && cid) setClassSlot(cid, teacherEdit.day, teacherEdit.p, slot)
          }
          setTeacherEdit(null)
        }}
      />
    </div>
  )
}

// ---------- meta strips ----------
function ClassMeta({ classId }: { classId: string }) {
  const { state } = useApp()
  const p = classProgress(state, classId)
  const pct = p.required ? Math.round((p.assigned / p.required) * 100) : 0
  return (
    <div className="mt-3 flex items-center gap-3">
      <div className="h-2.5 grow rounded-full bg-slate-100 overflow-hidden">
        <div className={`h-full ${pct === 100 ? 'bg-emerald-500' : 'bg-brand-600'}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-bold text-slate-600 shrink-0">{p.assigned}/{p.required} filled</span>
    </div>
  )
}
function TeacherMeta({ teacherId }: { teacherId: string }) {
  const { state } = useApp()
  const load = teacherWorkload(state, teacherId)
  const cap = DAYS.length * state.settings.periodsPerDay
  return (
    <div className="mt-3 flex items-center justify-between">
      <span className="text-xs text-slate-500">Total workload this week</span>
      <span className="chip bg-amber-50 text-amber-700">{load} / {cap} periods</span>
    </div>
  )
}

// ---------- grids ----------
function GridShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-2 overflow-x-auto">
      <table className="w-full border-collapse text-sm">{children}</table>
    </div>
  )
}
function HeadCells({ periods, first }: { periods: number; first: string }) {
  const { state } = useApp()
  return (
    <tr className="bg-brand-700 text-white">
      <th className="border border-brand-600 px-2 py-1.5 text-[11px] sticky left-0 bg-brand-700 z-10">{first}</th>
      {Array.from({ length: periods }).map((_, i) => (
        <th key={i} className="border border-brand-600 px-1 py-1.5 text-[10px] min-w-[78px]">
          P{i + 1}
          <div className="font-normal text-brand-100 text-[8px]">
            {state.timings[i]?.start}-{state.timings[i]?.end}
          </div>
        </th>
      ))}
    </tr>
  )
}

function ClassGridEditor({ classId, periods, onCell }: { classId: string; periods: number; onCell: (d: Day, p: number) => void }) {
  const { state } = useApp()
  const tt = getTimetable(state, classId)
  return (
    <GridShell>
      <thead><HeadCells periods={periods} first="DAY" /></thead>
      <tbody>
        {DAYS.map((d) => (
          <tr key={d}>
            <td className="border border-slate-200 px-2 py-1.5 text-[11px] font-bold bg-slate-50 sticky left-0">{d}</td>
            {Array.from({ length: periods }).map((_, p) => {
              const s = tt.grid[d]?.[p] ?? null
              const teacher = s?.teacherId ? findTeacher(state, s.teacherId) : null
              return (
                <td key={p} className="border border-slate-200 p-0">
                  <button onClick={() => onCell(d, p)} className="w-full h-full px-1 py-1.5 text-center active:bg-brand-50">
                    {s ? (
                      <>
                        <div className="text-[12px] font-bold text-slate-800 leading-tight">{cellSubject(state, s.subjectId).acr}</div>
                        <div className="text-[9px] text-slate-500 leading-tight">{teacher ? teacher.acronym || teacher.name.split(' ').slice(-1)[0] : '—'}</div>
                      </>
                    ) : (
                      <span className="text-slate-300 text-[10px]">+</span>
                    )}
                  </button>
                </td>
              )
            })}
          </tr>
        ))}
      </tbody>
    </GridShell>
  )
}

function TeacherGridEditor({ teacherId, periods, onCell }: { teacherId: string; periods: number; onCell: (d: Day, p: number) => void }) {
  const { state } = useApp()
  const wk = teacherWeek(state, teacherId)
  return (
    <GridShell>
      <thead><HeadCells periods={periods} first="DAY" /></thead>
      <tbody>
        {DAYS.map((d) => (
          <tr key={d}>
            <td className="border border-slate-200 px-2 py-1.5 text-[11px] font-bold bg-slate-50 sticky left-0">{d}</td>
            {Array.from({ length: periods }).map((_, p) => {
              const s = wk[d][p]
              const c = s ? state.classes.find((x) => x.id === s.classId) : null
              return (
                <td key={p} className="border border-slate-200 p-0">
                  <button onClick={() => onCell(d, p)} className="w-full h-full px-1 py-1.5 text-center active:bg-brand-50">
                    {s ? (
                      <>
                        <div className="text-[12px] font-bold text-slate-800 leading-tight">{c ? className(c) : '?'}</div>
                        <div className="text-[9px] text-slate-500 leading-tight">{cellSubject(state, s.subjectId).acr}</div>
                      </>
                    ) : (
                      <span className="text-slate-300 text-[10px]">+</span>
                    )}
                  </button>
                </td>
              )
            })}
          </tr>
        ))}
      </tbody>
    </GridShell>
  )
}

function DayGridEditor({ day, periods, onCell }: { day: Day; periods: number; onCell: (teacherId: string, p: number) => void }) {
  const { state } = useApp()
  return (
    <GridShell>
      <thead><HeadCells periods={periods} first="TEACHER" /></thead>
      <tbody>
        {state.teachers.map((t) => {
          const wk = teacherWeek(state, t.id)
          return (
            <tr key={t.id}>
              <td className="border border-slate-200 px-2 py-1.5 text-[10px] font-bold bg-slate-50 sticky left-0 max-w-[110px]">
                <div className="truncate">{t.name}</div>
                <div className="text-[8px] text-slate-400 font-normal">{postCode(state, t.id)}</div>
              </td>
              {Array.from({ length: periods }).map((_, p) => {
                const s = wk[day][p]
                const c = s ? state.classes.find((x) => x.id === s.classId) : null
                return (
                  <td key={p} className="border border-slate-200 p-0">
                    <button onClick={() => onCell(t.id, p)} className="w-full h-full px-1 py-1.5 text-center active:bg-brand-50">
                      {s ? (
                        <>
                          <div className="text-[11px] font-bold text-slate-800 leading-tight">{c ? className(c) : '?'}</div>
                          <div className="text-[9px] text-slate-500 leading-tight">{cellSubject(state, s.subjectId).acr}</div>
                        </>
                      ) : (
                        <span className="text-slate-300 text-[10px]">+</span>
                      )}
                    </button>
                  </td>
                )
              })}
            </tr>
          )
        })}
      </tbody>
    </GridShell>
  )
}

// ---------- edit modals ----------
function PendingPanel({ classId }: { classId: string }) {
  const { state } = useApp()
  const pending = pendingForClass(state, classId)
  if (pending.length === 0)
    return <p className="text-xs text-emerald-600 font-semibold">✓ All subjects fully assigned for this class.</p>
  return (
    <div className="rounded-xl bg-brand-50/60 border-l-4 border-brand-500 p-3">
      <p className="text-xs font-bold text-slate-700 mb-1.5">Pending subjects for this class</p>
      <div className="flex flex-wrap gap-1.5">
        {pending.map((r) => {
          const t = r.teacherId ? findTeacher(state, r.teacherId) : null
          return (
            <span key={r.subjectId} className="chip bg-white text-brand-700 border border-brand-100">
              {r.acronym}{t ? ` · ${t.acronym || t.name.split(' ').slice(-1)[0]}` : ''} <b className="ml-1">[{r.left} left]</b>
            </span>
          )
        })}
      </div>
    </div>
  )
}

function subjectOptions(state: ReturnType<typeof useApp>['state'], classId: string, currentSubjectId?: string) {
  const pending = pendingForClass(state, classId)
  const ids = new Set(pending.map((p) => p.subjectId))
  const list = pending.map((p) => ({ subjectId: p.subjectId, label: `${p.acronym} — ${p.left} left` }))
  if (currentSubjectId && !ids.has(currentSubjectId)) {
    const s = findSubject(state, currentSubjectId)
    list.unshift({ subjectId: currentSubjectId, label: `${s?.acronym ?? '?'} — keep current` })
  }
  return list
}

function ClassCellModal({
  target,
  onClose,
  onSave,
}: {
  target: { classId: string; day: Day; p: number } | null
  onClose: () => void
  onSave: (slot: Slot | null) => void
}) {
  const { state } = useApp()
  const [subjectId, setSubjectId] = useState('')
  const [teacherId, setTeacherId] = useState('')

  const open = !!target
  const cls = target ? state.classes.find((c) => c.id === target.classId) : null
  const cur = target ? getTimetable(state, target.classId).grid[target.day]?.[target.p] ?? null : null

  useEffect(() => {
    if (open) {
      setSubjectId(cur?.subjectId ?? '')
      setTeacherId(cur?.teacherId ?? '')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  if (!target) return null
  const subOpts = subjectOptions(state, target.classId, cur?.subjectId)

  return (
    <Modal
      open={open}
      onClose={onClose}
      icon="✏️"
      title="Manual Edit Period"
      footer={
        <div className="flex gap-2">
          {cur && <button onClick={() => onSave(null)} className="btn-danger grow">🧽 Clear Box</button>}
          <button onClick={() => subjectId && onSave({ subjectId, teacherId })} disabled={!subjectId} className="btn-primary grow">
            ✓ Save Changes
          </button>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="rounded-xl bg-brand-50 text-brand-700 font-bold text-sm px-3 py-2">
          Editing: Class {cls ? className(cls) : '?'} | {target.day} | Period {target.p + 1}
        </div>

        <div>
          <label className="label">Assign Subject (pending for this class)</label>
          <select className="input" value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
            <option value="">— Manual Entry / Leave Blank —</option>
            {subOpts.map((o) => (
              <option key={o.subjectId} value={o.subjectId}>{o.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="label">Assign Teacher (available first)</label>
          <select className="input" value={teacherId} onChange={(e) => setTeacherId(e.target.value)}>
            <option value="">— none —</option>
            <TeacherOptions day={target.day} period={target.p} exceptClassId={target.classId} />
          </select>
          {teacherId && (
            <p className="text-[11px] text-slate-500 mt-1">
              Workload: <b>{teacherWorkload(state, teacherId)}</b> periods/week
            </p>
          )}
        </div>

        <PendingPanel classId={target.classId} />
      </div>
    </Modal>
  )
}

function TeacherCellModal({
  target,
  onClose,
  onSave,
}: {
  target: { teacherId: string; day: Day; p: number } | null
  onClose: () => void
  onSave: (classId: string, slot: Slot | null) => void
}) {
  const { state } = useApp()
  const [classId, setClassId] = useState('')
  const [subjectId, setSubjectId] = useState('')

  const open = !!target
  const t = target ? findTeacher(state, target.teacherId) : null
  const cur = target ? teacherSlot(state, target.teacherId, target.day, target.p) : null

  // Classes that already have this period filled are hidden to avoid duplicates,
  // except the teacher's own current class (so it can be edited/kept).
  const classChoices = target
    ? state.classes.filter((c) => {
        const filled = getTimetable(state, c.id).grid[target.day]?.[target.p]
        return !filled || (cur && cur.classId === c.id)
      })
    : []

  useEffect(() => {
    if (open && target) {
      const first = cur?.classId ?? classChoices[0]?.id ?? ''
      setClassId(first)
      setSubjectId(cur?.classId === first ? cur?.subjectId ?? '' : '')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  if (!target) return null
  const subOpts = subjectOptions(state, classId, cur?.classId === classId ? cur?.subjectId : undefined)
  const conflict = teacherSlot(state, target.teacherId, target.day, target.p, classId)
  const commonBlocked = isCommonBusy(state, target.teacherId, target.day, target.p)

  return (
    <Modal
      open={open}
      onClose={onClose}
      icon="✏️"
      title="Manual Edit Period"
      footer={
        <div className="flex gap-2">
          {cur && <button onClick={() => onSave(cur.classId, null)} className="btn-danger grow">🧽 Clear Box</button>}
          <button
            onClick={() => classId && subjectId && onSave(classId, { subjectId, teacherId: target.teacherId })}
            disabled={!classId || !subjectId || commonBlocked}
            className="btn-primary grow"
          >
            ✓ Save Changes
          </button>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="rounded-xl bg-brand-50 text-brand-700 font-bold text-sm px-3 py-2">
          Editing: {t?.name} | {target.day} | Period {target.p + 1}
        </div>

        {commonBlocked && (
          <p className="text-xs font-semibold text-rose-600">
            🔒 This teacher is busy in the other section at this period (common teacher). They are
            not free — cannot assign here.
          </p>
        )}

        <div>
          <label className="label">Assign Class (only free classes shown)</label>
          <select className="input" value={classId} onChange={(e) => { setClassId(e.target.value); setSubjectId('') }}>
            {classChoices.length === 0 && <option value="">No free class this period</option>}
            {classChoices.map((c) => (
              <option key={c.id} value={c.id}>Class {className(c)}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="label">Assign Subject (pending for this class)</label>
          <select className="input" value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
            <option value="">— select subject —</option>
            {subOpts.map((o) => (
              <option key={o.subjectId} value={o.subjectId}>{o.label}</option>
            ))}
          </select>
        </div>

        {conflict && (
          <p className="text-xs text-amber-600">
            ⚠ This teacher is already taking {(() => { const c = state.classes.find((x) => x.id === conflict.classId); return c ? className(c) : '?' })()} ({findSubject(state, conflict.subjectId)?.acronym}) this period. Saving will move them here.
          </p>
        )}

        <p className="text-[11px] text-slate-500">
          Workload: <b>{teacherWorkload(state, target.teacherId)}</b> periods/week
        </p>

        <PendingPanel classId={classId} />
      </div>
    </Modal>
  )
}

/** Teacher <option>s with busy/available status, available listed first. */
function TeacherOptions({ day, period, exceptClassId }: { day: Day; period: number; exceptClassId: string }) {
  const { state } = useApp()
  const rows = state.teachers.map((t) => {
    const busy = teacherSlot(state, t.id, day, period, exceptClassId)
    const common = isCommonBusy(state, t.id, day, period)
    return { t, busy, common }
  })
  rows.sort((a, b) => (a.busy || a.common ? 1 : 0) - (b.busy || b.common ? 1 : 0))
  return (
    <>
      {rows.map(({ t, busy, common }) => {
        const c = busy ? state.classes.find((x) => x.id === busy.classId) : null
        const label = common
          ? `🔒 ${t.name} — busy (other section)`
          : busy
            ? `🔴 ${t.name} — busy: ${c ? className(c) : '?'} ${findSubject(state, busy.subjectId)?.acronym ?? ''}`
            : `🟢 ${t.name} (free)`
        return (
          <option key={t.id} value={t.id} disabled={common}>{label}</option>
        )
      })}
    </>
  )
}
