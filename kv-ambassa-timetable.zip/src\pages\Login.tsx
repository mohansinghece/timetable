import { useState } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import { useApp } from '../store/AppContext'

export default function Login() {
  const { login, isAdmin, state } = useApp()
  const navigate = useNavigate()
  const loc = useLocation() as { state?: { from?: string } }
  const [pw, setPw] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  if (isAdmin) return <Navigate to={loc.state?.from || '/'} replace />

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setErr('')
    const ok = await login(pw)
    setBusy(false)
    if (ok) navigate(loc.state?.from || '/', { replace: true })
    else setErr('Incorrect password. Default is "admin123".')
  }

  return (
    <div className="min-h-screen grid place-items-center px-5 bg-gradient-to-br from-brand-700 via-brand-800 to-accent-700">
      <div className="w-full max-w-sm">
        <div className="text-center text-white mb-6">
          <div className="h-16 w-16 rounded-2xl bg-white/15 grid place-items-center text-3xl mx-auto mb-3 backdrop-blur">
            📘
          </div>
          <h1 className="text-xl font-extrabold">{state.settings.schoolName}</h1>
          <p className="text-white/70 text-sm mt-1">Timetable & Arrangement Manager</p>
        </div>
        <form onSubmit={submit} className="bg-white rounded-3xl shadow-xl p-6 space-y-4">
          <div>
            <h2 className="font-bold text-slate-800 text-lg">Admin Login</h2>
            <p className="text-sm text-slate-500">Sign in to configure and build timetables.</p>
          </div>
          <div>
            <label className="label">Password</label>
            <input
              type="password"
              className="input"
              value={pw}
              autoFocus
              onChange={(e) => {
                setPw(e.target.value)
                setErr('')
              }}
              placeholder="Enter admin password"
            />
          </div>
          {err && <p className="text-sm text-red-600">{err}</p>}
          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy ? 'Signing in…' : 'Sign In →'}
          </button>
          <button
            type="button"
            onClick={() => navigate('/')}
            className="btn-ghost w-full"
          >
            👁 Continue as Viewer (no login)
          </button>
          <p className="text-center text-xs text-slate-400">
            Teachers can view timetables without logging in.
          </p>
        </form>
      </div>
    </div>
  )
}
