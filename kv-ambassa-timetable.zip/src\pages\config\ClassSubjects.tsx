import { useMemo, useState } from 'react'
import { useApp } from '../../store/AppContext'
import { Card, Empty, Modal, PageHeader } from '../../components/ui'
import { STAGE_LABELS, STAGE_TEMPLATES } from '../../lib/seed'
import { className } from '../../lib/timetable'
import { DAYS, DAY_LABELS } from '../../types'

export default function ClassSubjects() {
  const { state, update } = useApp()
  const [classId, setClassId] = useState(state.classes[0]?.id ?? '')
  const [addOpen, setAddOpen] = useState(false)

  const cls = state.classes.find((c) => c.id === classId)
  const cfg = state.classSubjects.find((c) => c.classId === classId)
  const capacity = state.settings.periodsPerDay * DAYS.length

  const total = useMemo(
    () => (cfg?.items ?? []).reduce((a, i) => a + i.periodsPerWeek, 0),
    [cfg],
  )

  const setPeriods = (subjectId: string, delta: number) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it) it.periodsPerWeek = Math.max(0, it.periodsPerWeek + delta)
    })

  const setPeriodsAbs = (subjectId: string, val: number) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it) it.periodsPerWeek = Math.max(0, val || 0)
    })

  const toggleBlock = (subjectId: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it) it.block = !it.block
    })

  const toggleMain = (subjectId: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it) it.main = !it.main
    })

  const toggleLock = (subjectId: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it) it.lockTeacher = !it.lockTeacher
    })

  const setTeacher = (subjectId: string, teacherId: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it) it.teacherId = teacherId || undefined
    })

  const toggleMulti = (subjectId: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (!it) return
      it.multiTeacher = !it.multiTeacher
      if (it.multiTeacher && (!it.teachers || it.teachers.length === 0)) {
        it.teachers = it.teacherId
          ? [{ teacherId: it.teacherId, periods: it.periodsPerWeek }]
          : [{ teacherId: '', periods: it.periodsPerWeek }]
      }
    })

  const addSubjectTeacher = (subjectId: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (!it) return
      it.teachers = [...(it.teachers ?? []), { teacherId: '', periods: 0 }]
    })

  const setSubjectTeacherAt = (subjectId: string, idx: number, teacherId: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it?.teachers?.[idx]) it.teachers[idx].teacherId = teacherId
    })

  const setSubjectTeacherPeriods = (subjectId: string, idx: number, periods: number) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it?.teachers?.[idx]) it.teachers[idx].periods = Math.max(0, periods || 0)
    })

  const removeSubjectTeacherAt = (subjectId: string, idx: number) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it?.teachers) it.teachers = it.teachers.filter((_, i) => i !== idx)
    })

  const setFixedDay = (subjectId: string, val: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it) it.fixedDay = (val || undefined) as any
    })

  const setFixedStart = (subjectId: string, val: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      const it = c?.items.find((i) => i.subjectId === subjectId)
      if (it) it.fixedStartPeriod = val === '' ? undefined : Number(val)
    })

  const removeSubject = (subjectId: string) =>
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      if (c) c.items = c.items.filter((i) => i.subjectId !== subjectId)
    })

  const addSubject = (subjectId: string) => {
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      if (c && !c.items.some((i) => i.subjectId === subjectId))
        c.items.push({ subjectId, periodsPerWeek: 1, block: false })
    })
  }

  const resetTemplate = () => {
    if (!cls) return
    if (!confirm('Reset this class to the default stage template?')) return
    update((d) => {
      const c = d.classSubjects.find((x) => x.classId === classId)
      if (c)
        c.items = STAGE_TEMPLATES[cls.stage].map((t) => ({
          subjectId: t.subjectId,
          periodsPerWeek: t.periodsPerWeek,
          block: !!t.block,
          main: !!t.main,
          lockTeacher: !!t.main,
        }))
    })
  }

  const available = state.subjects.filter(
    (s) => !cfg?.items.some((i) => i.subjectId === s.id),
  )

  // Group related subjects under a parent label (display only), matched by name
  // so it's robust to acronym changes.
  const items = cfg?.items ?? []
  const groupOf = (sid: string): string | undefined => {
    const n = (state.subjects.find((s) => s.id === sid)?.name ?? '').toLowerCase()
    if (n.includes('visual art') || n.includes('performing art')) return 'Arts Education'
    if (n.includes('games') || n.includes('yoga') || n.includes('physical education'))
      return 'Physical Education (PE)'
    return undefined
  }
  const displayList: ({ header: string; periods: number } | { item: (typeof items)[number] })[] = []
  const seen = new Set<string>()
  for (const it of items) {
    if (seen.has(it.subjectId)) continue
    const g = groupOf(it.subjectId)
    if (g) {
      const members = items.filter((x) => groupOf(x.subjectId) === g)
      members.forEach((m) => seen.add(m.subjectId))
      displayList.push({ header: g, periods: members.reduce((a, m) => a + m.periodsPerWeek, 0) })
      members.forEach((m) => displayList.push({ item: m }))
    } else {
      seen.add(it.subjectId)
      displayList.push({ item: it })
    }
  }

  return (
    <div>
      <PageHeader title="Subjects per Class" />
      {state.classes.length === 0 ? (
        <Empty icon="🧮" text="Add classes first." />
      ) : (
        <>
          <Card className="mb-3">
            <label className="label">Select class</label>
            <select className="input" value={classId} onChange={(e) => setClassId(e.target.value)}>
              {state.classes.map((c) => (
                <option key={c.id} value={c.id}>
                  Class {className(c)} — {STAGE_LABELS[c.stage]}
                </option>
              ))}
            </select>
            <div className="flex items-center justify-between mt-3">
              <div>
                <p className="text-xs text-slate-500">Total periods / week</p>
                <p
                  className={`text-lg font-extrabold ${
                    total === capacity ? 'text-emerald-600' : total > capacity ? 'text-red-600' : 'text-slate-800'
                  }`}
                >
                  {total}{' '}
                  <span className="text-sm font-semibold text-slate-400">/ {capacity}</span>
                </p>
              </div>
              <div className="flex gap-2">
                <button onClick={resetTemplate} className="btn-ghost text-xs">↺ Reset</button>
                <button onClick={() => setAddOpen(true)} className="btn-primary text-xs">+ Subject</button>
              </div>
            </div>
            {total !== capacity && (
              <p className={`text-xs mt-2 ${total > capacity ? 'text-red-600' : 'text-amber-600'}`}>
                {total > capacity
                  ? `Over capacity by ${total - capacity}. Reduce some periods.`
                  : `${capacity - total} periods still free in the week.`}
              </p>
            )}
          </Card>

          <div className="space-y-2">
            {displayList.map((entry) => {
              if ('header' in entry)
                return (
                  <div
                    key={`h-${entry.header}`}
                    className="flex items-center justify-between rounded-xl bg-gradient-to-r from-brand-700 to-accent-700 text-white px-3 py-2 mt-3"
                  >
                    <span className="font-bold text-sm">🎯 {entry.header}</span>
                    <span className="text-xs font-semibold bg-white/15 rounded-lg px-2 py-0.5">
                      {entry.periods} periods/week
                    </span>
                  </div>
                )
              const it = entry.item
              const grouped = !!groupOf(it.subjectId)
              const s = state.subjects.find((x) => x.id === it.subjectId)
              return (
                <Card
                  key={it.subjectId}
                  className={`space-y-2 ${grouped ? 'border-l-4 border-l-accent-300 ml-2' : ''}`}
                >
                  <div className="flex items-center gap-2">
                    <span className="chip bg-indigo-50 text-indigo-700 min-w-[3.5rem] justify-center shrink-0">
                      {s?.acronym ?? '?'}
                    </span>
                    <div className="grow min-w-0">
                      <p className="text-sm font-semibold text-slate-800 truncate">{s?.name}</p>
                      <div className="mt-1 flex flex-wrap gap-1.5">
                        <button
                          onClick={() => toggleBlock(it.subjectId)}
                          className={`chip text-[10px] ${
                            it.block ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {it.block ? '✓ Block' : 'Block'}
                        </button>
                        <button
                          onClick={() => toggleMain(it.subjectId)}
                          className={`chip text-[10px] ${
                            it.main ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {it.main ? '✓ Main (daily)' : 'Main subject'}
                        </button>
                        <button
                          onClick={() => toggleLock(it.subjectId)}
                          className={`chip text-[10px] ${
                            it.lockTeacher ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {it.lockTeacher ? '🔒 Locked teacher' : 'Lock teacher'}
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button onClick={() => setPeriods(it.subjectId, -1)} className="h-8 w-8 rounded-lg bg-slate-100 font-bold text-slate-600">
                        −
                      </button>
                      <input
                        className="w-10 text-center input px-0 py-1.5 font-bold"
                        value={it.periodsPerWeek}
                        onChange={(e) => setPeriodsAbs(it.subjectId, parseInt(e.target.value))}
                      />
                      <button onClick={() => setPeriods(it.subjectId, 1)} className="h-8 w-8 rounded-lg bg-slate-100 font-bold text-slate-600">
                        +
                      </button>
                      <button onClick={() => removeSubject(it.subjectId)} className="text-red-400 px-1.5">🗑️</button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-semibold text-slate-400">👩‍🏫 Teacher</span>
                      <button
                        onClick={() => toggleMulti(it.subjectId)}
                        className={`chip text-[10px] ${
                          it.multiTeacher ? 'bg-accent-100 text-accent-700' : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {it.multiTeacher ? '✓ Multiple teachers' : 'Multiple teachers'}
                      </button>
                    </div>

                    {!it.multiTeacher ? (
                      <select
                        className="input py-1.5 text-sm"
                        value={it.teacherId ?? ''}
                        onChange={(e) => setTeacher(it.subjectId, e.target.value)}
                      >
                        <option value="">— select teacher —</option>
                        {state.teachers.map((t) => (
                          <option key={t.id} value={t.id}>
                            {t.name}
                            {t.acronym ? ` (${t.acronym})` : ''}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <div className="space-y-2">
                        {(it.teachers ?? []).map((row, idx) => (
                          <div key={idx} className="flex items-center gap-1.5">
                            <select
                              className="input py-1.5 text-sm grow"
                              value={row.teacherId}
                              onChange={(e) => setSubjectTeacherAt(it.subjectId, idx, e.target.value)}
                            >
                              <option value="">— teacher —</option>
                              {state.teachers.map((t) => (
                                <option key={t.id} value={t.id}>
                                  {t.name}
                                  {t.acronym ? ` (${t.acronym})` : ''}
                                </option>
                              ))}
                            </select>
                            <input
                              type="number"
                              className="input py-1.5 px-1 text-sm w-14 text-center"
                              value={row.periods}
                              onChange={(e) => setSubjectTeacherPeriods(it.subjectId, idx, parseInt(e.target.value))}
                              title="periods / week"
                            />
                            <button onClick={() => removeSubjectTeacherAt(it.subjectId, idx)} className="text-red-400 px-1">🗑️</button>
                          </div>
                        ))}
                        {(() => {
                          const sum = (it.teachers ?? []).reduce((a, r) => a + (r.periods || 0), 0)
                          const ok = sum === it.periodsPerWeek
                          return (
                            <div className="flex items-center justify-between">
                              <button onClick={() => addSubjectTeacher(it.subjectId)} className="btn-soft text-xs py-1">
                                + Add teacher
                              </button>
                              <span className={`text-[11px] font-semibold ${ok ? 'text-emerald-600' : 'text-amber-600'}`}>
                                {sum}/{it.periodsPerWeek} periods split
                              </span>
                            </div>
                          )
                        })()}
                      </div>
                    )}
                  </div>
                  {s?.acronym === 'CLA' && (
                    <div className="rounded-xl bg-amber-50/70 p-2.5 space-y-2">
                      <p className="text-[11px] font-bold text-amber-700">
                        📅 Fixed slot for CLA (optional) — usually Saturday P1–P2 block
                      </p>
                      <div className="flex items-center gap-2">
                        <select
                          className="input py-1.5 text-sm"
                          value={it.fixedDay ?? ''}
                          onChange={(e) => setFixedDay(it.subjectId, e.target.value)}
                        >
                          <option value="">Any day (auto)</option>
                          {DAYS.map((d) => (
                            <option key={d} value={d}>
                              {DAY_LABELS[d]}
                            </option>
                          ))}
                        </select>
                        <select
                          className="input py-1.5 text-sm"
                          value={it.fixedStartPeriod ?? ''}
                          onChange={(e) => setFixedStart(it.subjectId, e.target.value)}
                        >
                          <option value="">Any period</option>
                          {Array.from({ length: state.settings.periodsPerDay }).map((_, p) => (
                            <option key={p} value={p}>
                              {it.block ? `P${p + 1}–P${p + 2}` : `P${p + 1}`}
                            </option>
                          ))}
                        </select>
                      </div>
                      {it.block && (
                        <p className="text-[10px] text-amber-600">
                          Block period — fills the chosen period and the next one on that day.
                        </p>
                      )}
                    </div>
                  )}
                </Card>
              )
            })}
          </div>
        </>
      )}

      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Add Subject to Class" icon="➕">
        {available.length === 0 ? (
          <p className="text-sm text-slate-500">All subjects already added.</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {available.map((s) => (
              <button
                key={s.id}
                onClick={() => {
                  addSubject(s.id)
                  setAddOpen(false)
                }}
                className="chip border bg-white text-slate-700 border-slate-200"
              >
                {s.acronym} · {s.name}
              </button>
            ))}
          </div>
        )}
      </Modal>
    </div>
  )
}
