import { AppState } from '../types'
import { seedState } from './seed'

const KEY = 'kv-ambassa-timetable:v1'

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return seedState()
    const parsed = JSON.parse(raw) as Partial<AppState>
    // Merge with seed to tolerate older/partial saves.
    const base = seedState()
    return { ...base, ...parsed } as AppState
  } catch {
    return seedState()
  }
}

export function saveState(state: AppState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state))
  } catch (e) {
    console.error('Failed to save state', e)
  }
}

export function clearState() {
  localStorage.removeItem(KEY)
}
