import { useApp } from '../store/AppContext'
import { classProgress, className } from '../lib/timetable'

/** Per-subject "assigned / required" breakdown for a class (NEP period audit). */
export default function SubjectTally({ classId }: { classId: string }) {
  const { state } = useApp()
  const cls = state.classes.find((c) => c.id === classId)
  const p = classProgress(state, classId)
  const done = p.assigned >= p.required && p.required > 0

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-brand-700 to-accent-700 text-white">
        <span className="font-extrabold">Class {cls ? className(cls) : '?'}</span>
        <span className="font-extrabold tabular-nums">
          {p.assigned} / {p.required}
        </span>
      </div>
      <div className="divide-y divide-slate-100">
        {p.rows.map((r) => {
          const full = r.assigned >= r.required
          const over = r.assigned > r.required
          return (
            <div key={r.subjectId} className="flex items-center justify-between px-4 py-2.5">
              <span
                className={`text-sm font-semibold ${
                  full ? 'text-emerald-600' : r.assigned > 0 ? 'text-amber-600' : 'text-rose-500'
                }`}
              >
                {r.name}
              </span>
              <span
                className={`text-sm font-bold tabular-nums ${
                  over ? 'text-rose-600' : full ? 'text-emerald-600' : r.assigned > 0 ? 'text-amber-600' : 'text-rose-500'
                }`}
              >
                {r.assigned} / {r.required}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
