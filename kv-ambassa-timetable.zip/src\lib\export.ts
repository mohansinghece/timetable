import * as XLSX from 'xlsx'
import { AppState, DAYS, DAY_LABELS } from '../types'
import { cellSubject, className, findSubject, findTeacher, getTimetable, postCode, teacherWeek } from './timetable'

type Row = (string | number)[]

function cellText(state: AppState, subjectId: string, teacherId: string): string {
  const acr = cellSubject(state, subjectId).acr
  const t = teacherId ? findTeacher(state, teacherId) : null
  return t ? `${acr} / ${t.name}` : acr
}

function periodHeader(state: AppState): Row {
  return ['DAY \\ PERIOD', ...Array.from({ length: state.settings.periodsPerDay }, (_, i) => `P${i + 1}`)]
}

export function buildClassWiseSheet(state: AppState): Row[] {
  const rows: Row[] = []
  for (const c of state.classes) {
    const tt = getTimetable(state, c.id)
    rows.push([`CLASS ${className(c)}`])
    rows.push(periodHeader(state))
    for (const d of DAYS) {
      rows.push([
        DAY_LABELS[d],
        ...(tt.grid[d] ?? []).map((s) => (s ? cellText(state, s.subjectId, s.teacherId) : '')),
      ])
    }
    rows.push([])
  }
  return rows
}

export function buildTeacherWiseSheet(state: AppState): Row[] {
  const rows: Row[] = []
  for (const t of state.teachers) {
    const wk = teacherWeek(state, t.id)
    rows.push([`${t.name} (${postCode(state, t.id)})`])
    rows.push(periodHeader(state))
    for (const d of DAYS) {
      rows.push([
        DAY_LABELS[d],
        ...wk[d].map((s) => {
          if (!s) return ''
          const c = state.classes.find((x) => x.id === s.classId)
          return `${c ? className(c) : '?'} ${cellSubject(state, s.subjectId).acr}`
        }),
      ])
    }
    rows.push([])
  }
  return rows
}

export function buildDayWiseSheet(state: AppState): Row[] {
  const rows: Row[] = []
  for (const d of DAYS) {
    rows.push([DAY_LABELS[d].toUpperCase()])
    rows.push(['CLASS', ...Array.from({ length: state.settings.periodsPerDay }, (_, i) => `P${i + 1}`)])
    for (const c of state.classes) {
      const tt = getTimetable(state, c.id)
      rows.push([
        className(c),
        ...(tt.grid[d] ?? []).map((s) => (s ? cellText(state, s.subjectId, s.teacherId) : '')),
      ])
    }
    rows.push([])
  }
  return rows
}

export function exportWorkbook(state: AppState) {
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.aoa_to_sheet(buildClassWiseSheet(state)),
    'Class-wise',
  )
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.aoa_to_sheet(buildTeacherWiseSheet(state)),
    'Teacher-wise',
  )
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(buildDayWiseSheet(state)), 'Day-wise')
  const date = new Date().toISOString().slice(0, 10)
  XLSX.writeFile(wb, `KV-Ambassa-Timetable-${date}.xlsx`)
}

/** Export the full app state as JSON (backup that can be re-imported). */
export function exportBackup(state: AppState) {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `kv-timetable-backup-${new Date().toISOString().slice(0, 10)}.json`
  a.click()
  URL.revokeObjectURL(url)
}

export function printView() {
  window.print()
}
