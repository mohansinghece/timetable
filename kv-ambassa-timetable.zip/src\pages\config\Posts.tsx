import { useState } from 'react'
import { useApp } from '../../store/AppContext'
import { Card, Empty, Modal, PageHeader } from '../../components/ui'
import { uid } from '../../lib/seed'
import { Post } from '../../types'

export default function Posts() {
  const { state, update } = useApp()
  const [open, setOpen] = useState(false)
  const [edit, setEdit] = useState<Post | null>(null)
  const [name, setName] = useState('')
  const [code, setCode] = useState('')

  const start = (p?: Post) => {
    setEdit(p ?? null)
    setName(p?.name ?? '')
    setCode(p?.code ?? '')
    setOpen(true)
  }

  const save = () => {
    if (!name.trim() || !code.trim()) return
    update((d) => {
      if (edit) {
        const t = d.posts.find((x) => x.id === edit.id)
        if (t) {
          t.name = name.trim()
          t.code = code.trim().toUpperCase()
        }
      } else {
        d.posts.push({ id: uid(), name: name.trim(), code: code.trim().toUpperCase() })
      }
    })
    setOpen(false)
  }

  const remove = (p: Post) => {
    const used = state.teachers.some((t) => t.postId === p.id)
    if (used) {
      alert('This post is assigned to teachers. Reassign them before deleting.')
      return
    }
    if (!confirm(`Delete post "${p.name}"?`)) return
    update((d) => {
      d.posts = d.posts.filter((x) => x.id !== p.id)
    })
  }

  return (
    <div>
      <PageHeader
        title="Posts / Designations"
        right={
          <button onClick={() => start()} className="btn-primary text-xs">
            + Add
          </button>
        }
      />
      {state.posts.length === 0 ? (
        <Empty icon="🏷️" text="No posts yet. Add PRT, TGT, PGT…" />
      ) : (
        <div className="space-y-2">
          {state.posts.map((p) => (
            <Card key={p.id} className="flex items-center gap-3">
              <span className="chip bg-brand-50 text-brand-700">{p.code}</span>
              <span className="grow font-semibold text-slate-800">{p.name}</span>
              <button onClick={() => start(p)} className="text-slate-400 px-2">✏️</button>
              <button onClick={() => remove(p)} className="text-red-400 px-2">🗑️</button>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={edit ? 'Edit Post' : 'Add Post'}
        icon="🏷️"
        footer={
          <button onClick={save} className="btn-primary w-full">
            Save
          </button>
        }
      >
        <div className="space-y-3">
          <div>
            <label className="label">Post name</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Trained Graduate Teacher" />
          </div>
          <div>
            <label className="label">Short code</label>
            <input className="input uppercase" value={code} onChange={(e) => setCode(e.target.value)} placeholder="e.g. TGT" />
          </div>
        </div>
      </Modal>
    </div>
  )
}
