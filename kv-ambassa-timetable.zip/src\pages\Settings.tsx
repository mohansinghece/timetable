import { useRef, useState } from 'react'
import { useApp } from '../store/AppContext'
import { Card, PageHeader } from '../components/ui'
import { exportBackup, exportWorkbook } from '../lib/export'
import { AppState } from '../types'

export default function Settings() {
  const { state, update, replace, reset, autoSave, setAutoSave, saveNow, sync } = useApp()
  const [school, setSchool] = useState(state.settings.schoolName)
  const [pw, setPw] = useState(state.settings.adminPassword)
  const fileRef = useRef<HTMLInputElement>(null)
  const [msg, setMsg] = useState('')

  const saveGeneral = () =>
    update((d) => {
      d.settings.schoolName = school.trim() || d.settings.schoolName
      d.settings.adminPassword = pw.trim() || d.settings.adminPassword
    })

  const onImport = (file: File) => {
    const r = new FileReader()
    r.onload = () => {
      try {
        const data = JSON.parse(String(r.result)) as AppState
        if (!data.settings || !Array.isArray(data.classes)) throw new Error('bad file')
        replace(data)
        setMsg('✅ Backup imported — full timetable restored.')
      } catch {
        setMsg('❌ Invalid backup file.')
      }
    }
    r.readAsText(file)
  }

  return (
    <div>
      <PageHeader title="Settings & Data" />

      <Card className="mb-3 space-y-3">
        <h2 className="font-bold text-slate-800">Saving</h2>
        <button onClick={() => setAutoSave(!autoSave)} className="w-full flex items-center gap-3 text-left">
          <div className={`h-6 w-11 rounded-full transition shrink-0 relative ${autoSave ? 'bg-brand-600' : 'bg-slate-300'}`}>
            <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${autoSave ? 'left-[1.4rem]' : 'left-0.5'}`} />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-800">Auto-save</p>
            <p className="text-xs text-slate-400">
              {autoSave ? 'Changes save to the server automatically.' : 'Changes stay on this device until you press Save.'}
            </p>
          </div>
        </button>
        {!autoSave && (
          <button onClick={() => saveNow()} className="btn-primary w-full">
            {sync === 'unsaved' ? '💾 Save now (unsaved changes)' : '💾 Save now'}
          </button>
        )}
      </Card>

      <Card className="mb-3 space-y-3">
        <h2 className="font-bold text-slate-800">General</h2>
        <div>
          <label className="label">School name</label>
          <input className="input" value={school} onChange={(e) => setSchool(e.target.value)} />
        </div>
        <div>
          <label className="label">Admin password</label>
          <input className="input" value={pw} onChange={(e) => setPw(e.target.value)} />
        </div>
        <button onClick={saveGeneral} className="btn-primary w-full">Save</button>
      </Card>

      <Card className="mb-3 space-y-2">
        <h2 className="font-bold text-slate-800">Full backup</h2>
        <p className="text-xs text-slate-500">
          The JSON backup contains <b>everything</b> — classes, teachers, subjects, settings,
          breaks and the complete timetables. Importing it restores the whole timetable exactly as
          it was. Excel is for printing/sharing (Class · Teacher · Day sheets).
        </p>
        <button onClick={() => exportBackup(state)} className="btn-primary w-full">⬇ Download Full Backup (.json)</button>
        <button onClick={() => exportWorkbook(state)} className="btn-soft w-full">⬇ Download Excel (.xlsx)</button>
      </Card>

      <Card className="mb-3 space-y-2">
        <h2 className="font-bold text-slate-800">Restore backup</h2>
        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && onImport(e.target.files[0])}
        />
        <button onClick={() => fileRef.current?.click()} className="btn-ghost w-full">
          ⬆ Import Full Backup (.json)
        </button>
        <p className="text-[11px] text-slate-400">Importing replaces all current data (you can Undo from the header).</p>
        {msg && <p className="text-sm text-slate-600">{msg}</p>}
      </Card>

      <Card className="space-y-2">
        <h2 className="font-bold text-red-600">Danger Zone</h2>
        <p className="text-xs text-slate-500">Resets everything to defaults (classes, teachers, timetables).</p>
        <button
          onClick={() => {
            if (confirm('Reset ALL data to defaults? This cannot be undone.')) {
              reset()
              setMsg('Data reset to defaults.')
            }
          }}
          className="btn-danger w-full"
        >
          🗑️ Reset All Data
        </button>
      </Card>
    </div>
  )
}
