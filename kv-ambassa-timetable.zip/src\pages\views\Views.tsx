import { useState } from 'react'
import React from 'react'
import { useApp } from '../../store/AppContext'
import { Card } from '../../components/ui'
import { DAYS, DAY_LABELS, Day, Slot } from '../../types'
import {
  className,
  cellSubject,
  findSubject,
  findTeacher,
  getTimetable,
  subjectColor,
  teacherWeek,
  teacherWorkload,
} from '../../lib/timetable'
import { exportWorkbook, printView } from '../../lib/export'

type Mode = 'class' | 'teacher' | 'day'
type LabelMode = 'acr' | 'full'
type Column = { type: 'period'; i: number } | { type: 'break'; i: number }

const exact = { WebkitPrintColorAdjust: 'exact', printColorAdjust: 'exact' } as React.CSSProperties

function buildColumns(timings: { breakAfter?: unknown }[], periods: number): Column[] {
  const cols: Column[] = []
  for (let i = 0; i < periods; i++) {
    cols.push({ type: 'period', i })
    if (timings[i]?.breakAfter) cols.push({ type: 'break', i })
  }
  return cols
}

const lastName = (n: string) => n.split(' ').slice(-1)[0]

export default function Views() {
  const { state } = useApp()
  const [mode, setMode] = useState<Mode>('class')
  const [label, setLabel] = useState<LabelMode>('acr')
  const [classId, setClassId] = useState(state.classes[0]?.id ?? '')
  const [teacherId, setTeacherId] = useState(state.teachers[0]?.id ?? '')
  const [day, setDay] = useState<Day>('MON')

  const periods = state.settings.periodsPerDay
  const cols = buildColumns(state.timings, periods)

  return (
    <div>
      <div className="no-print">
        <div className="flex items-center justify-between mb-3 px-1">
          <h1 className="text-lg font-extrabold text-slate-800">Timetables</h1>
          <div className="flex gap-2">
            <button onClick={() => exportWorkbook(state)} className="btn-soft text-xs">⬇ Excel</button>
            <button onClick={printView} className="btn-ghost text-xs">🖨 PDF</button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-3">
          {(['class', 'teacher', 'day'] as Mode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`rounded-xl py-2.5 text-sm font-bold border capitalize ${
                mode === m ? 'bg-brand-700 text-white border-brand-700' : 'bg-white text-slate-600 border-slate-200'
              }`}
            >
              {m}-wise
            </button>
          ))}
        </div>

        <div className="flex gap-2 mb-3">
          {(['acr', 'full'] as LabelMode[]).map((l) => (
            <button
              key={l}
              onClick={() => setLabel(l)}
              className={`grow rounded-xl py-2 text-xs font-bold border ${
                label === l ? 'bg-accent-600 text-white border-accent-600' : 'bg-white text-slate-600 border-slate-200'
              }`}
            >
              {l === 'acr' ? 'Acronym' : 'Full name'}
            </button>
          ))}
        </div>

        <Card className="mb-3">
          {mode === 'class' && (
            <select className="input" value={classId} onChange={(e) => setClassId(e.target.value)}>
              {state.classes.map((c) => (
                <option key={c.id} value={c.id}>Class {className(c)}</option>
              ))}
            </select>
          )}
          {mode === 'teacher' && (
            <select className="input" value={teacherId} onChange={(e) => setTeacherId(e.target.value)}>
              {state.teachers.map((t) => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          )}
          {mode === 'day' && (
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
              {DAYS.map((d) => (
                <button
                  key={d}
                  onClick={() => setDay(d)}
                  className={`px-3.5 py-2 rounded-xl text-sm font-bold shrink-0 ${
                    day === d ? 'bg-brand-700 text-white' : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          )}
        </Card>
      </div>

      <div className="print-area bg-white rounded-2xl border border-slate-100 p-3 overflow-x-auto">
        <div className="text-center mb-2">
          <p className="font-bold text-slate-800 text-sm">{state.settings.schoolName}</p>
          <p className="text-[11px] text-slate-500">Time Table 2025–26</p>
          <p className="text-xs font-semibold text-brand-700 mt-0.5">
            {mode === 'class' && `Class ${className(state.classes.find((c) => c.id === classId) ?? ({} as any))}`}
            {mode === 'teacher' && findTeacher(state, teacherId)?.name}
            {mode === 'day' && DAY_LABELS[day]}
          </p>
        </div>

        <table className="w-full border-collapse text-sm">
          <thead>
            <HeadRow cols={cols} first={mode === 'day' ? 'CLASS' : 'DAY'} label={label} />
          </thead>
          <tbody>
            {mode === 'class' && <ClassRows classId={classId} cols={cols} label={label} />}
            {mode === 'teacher' && <TeacherRows teacherId={teacherId} cols={cols} label={label} />}
            {mode === 'day' && <DayRows day={day} cols={cols} label={label} />}
          </tbody>
        </table>
      </div>

      {mode === 'class' && <ClassDetails classId={classId} />}
      {mode === 'teacher' && <TeacherDetails teacherId={teacherId} />}
    </div>
  )
}

function HeadRow({ cols, first, label }: { cols: Column[]; first: string; label: LabelMode }) {
  const { state } = useApp()
  return (
    <tr className="bg-brand-700 text-white">
      <th className="border border-brand-600 px-2 py-1.5 text-[11px] font-bold sticky left-0 bg-brand-700">{first}</th>
      {cols.map((col, ci) => {
        const t = state.timings[col.i]
        if (col.type === 'break')
          return (
            <th key={ci} className="border border-amber-300 bg-amber-500 px-1 py-1.5 text-[9px] font-bold min-w-[40px]" style={exact}>
              {t?.breakAfter?.label ?? 'Break'}
              <div className="font-normal text-amber-50 text-[8px]">{t?.end}-{t?.breakAfter?.end}</div>
            </th>
          )
        return (
          <th key={ci} className="border border-brand-600 px-1 py-1.5 text-[10px] font-bold min-w-[64px]">
            {label === 'full' ? `Period ${col.i + 1}` : `P${col.i + 1}`}
            <div className="font-normal text-brand-100 text-[8px]">{t?.start}-{t?.end}</div>
          </th>
        )
      })}
    </tr>
  )
}

/** A coloured subject cell: main label + secondary line. */
function SubjectTd({ slot, main, secondary }: { slot: Slot; main: string; secondary?: string }) {
  const { state } = useApp()
  return (
    <td className="border border-slate-200 px-1 py-1.5 text-center align-middle" style={{ background: subjectColor(state, slot.subjectId) + '40', ...exact }}>
      <div className="text-[11px] font-bold text-slate-800 leading-tight">{main}</div>
      {secondary && <div className="text-[9px] text-slate-600 leading-tight">{secondary}</div>}
    </td>
  )
}
const EmptyTd = () => (
  <td className="border border-slate-200 px-1 py-1.5 text-center"><span className="text-slate-300 text-[10px]">—</span></td>
)
const BreakTd = () => <td className="border border-amber-200 bg-amber-100" style={exact} />

function ClassRows({ classId, cols, label }: { classId: string; cols: Column[]; label: LabelMode }) {
  const { state } = useApp()
  const tt = getTimetable(state, classId)
  return (
    <>
      {DAYS.map((d) => (
        <tr key={d}>
          <td className="border border-slate-200 px-2 py-1.5 text-[11px] font-bold bg-slate-50 sticky left-0">{label === 'full' ? DAY_LABELS[d] : DAY_LABELS[d].slice(0, 3)}</td>
          {cols.map((col, ci) => {
            if (col.type === 'break') return <BreakTd key={ci} />
            const s = tt.grid[d]?.[col.i] ?? null
            if (!s) return <EmptyTd key={ci} />
            const cs = cellSubject(state, s.subjectId)
            const t = s.teacherId ? findTeacher(state, s.teacherId) : null
            const tName = t ? (label === 'full' ? t.name : t.acronym || lastName(t.name)) : undefined
            return <SubjectTd key={ci} slot={s} main={label === 'full' ? cs.name : cs.acr} secondary={tName} />
          })}
        </tr>
      ))}
    </>
  )
}

function TeacherRows({ teacherId, cols, label }: { teacherId: string; cols: Column[]; label: LabelMode }) {
  const { state } = useApp()
  const wk = teacherWeek(state, teacherId)
  return (
    <>
      {DAYS.map((d) => (
        <tr key={d}>
          <td className="border border-slate-200 px-2 py-1.5 text-[11px] font-bold bg-slate-50 sticky left-0">{label === 'full' ? DAY_LABELS[d] : DAY_LABELS[d].slice(0, 3)}</td>
          {cols.map((col, ci) => {
            if (col.type === 'break') return <BreakTd key={ci} />
            const ws = wk[d][col.i]
            if (!ws) return <EmptyTd key={ci} />
            const c = state.classes.find((x) => x.id === ws.classId)
            const cs = cellSubject(state, ws.subjectId)
            const slot: Slot = { subjectId: ws.subjectId, teacherId }
            return <SubjectTd key={ci} slot={slot} main={c ? className(c) : '?'} secondary={label === 'full' ? cs.name : cs.acr} />
          })}
        </tr>
      ))}
    </>
  )
}

function DayRows({ day, cols, label }: { day: Day; cols: Column[]; label: LabelMode }) {
  const { state } = useApp()
  return (
    <>
      {state.classes.map((c) => {
        const tt = getTimetable(state, c.id)
        return (
          <tr key={c.id}>
            <td className="border border-slate-200 px-2 py-1.5 text-[11px] font-bold bg-slate-50 sticky left-0">{className(c)}</td>
            {cols.map((col, ci) => {
              if (col.type === 'break') return <BreakTd key={ci} />
              const s = tt.grid[day]?.[col.i] ?? null
              if (!s) return <EmptyTd key={ci} />
              const cs = cellSubject(state, s.subjectId)
              const t = s.teacherId ? findTeacher(state, s.teacherId) : null
              const tName = t ? (label === 'full' ? t.name : t.acronym || lastName(t.name)) : undefined
              return <SubjectTd key={ci} slot={s} main={label === 'full' ? cs.name : cs.acr} secondary={tName} />
            })}
          </tr>
        )
      })}
    </>
  )
}

/** Class-wise breakdown: subject · teacher · periods (+ total). */
function ClassDetails({ classId }: { classId: string }) {
  const { state } = useApp()
  const tt = getTimetable(state, classId)
  const counts: Record<string, number> = {}
  for (const d of DAYS)
    for (const s of tt.grid[d] ?? [])
      if (s) counts[`${s.subjectId}|${s.teacherId}`] = (counts[`${s.subjectId}|${s.teacherId}`] ?? 0) + 1
  const rows = Object.entries(counts)
    .map(([k, n]) => {
      const [sid, tid] = k.split('|')
      return {
        subject: findSubject(state, sid)?.name ?? '?',
        teacher: tid ? findTeacher(state, tid)?.name ?? '—' : '—',
        n,
      }
    })
    .sort((a, b) => a.subject.localeCompare(b.subject))
  const total = rows.reduce((a, r) => a + r.n, 0)

  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-3 mt-3 overflow-x-auto no-print">
      <p className="font-bold text-slate-800 text-sm mb-2">📋 Subject details</p>
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="bg-slate-100 text-slate-600 text-xs">
            <th className="border border-slate-200 px-2 py-1.5 text-left">Subject</th>
            <th className="border border-slate-200 px-2 py-1.5 text-left">Teacher</th>
            <th className="border border-slate-200 px-2 py-1.5 w-20">Periods</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              <td className="border border-slate-200 px-2 py-1.5 font-semibold text-slate-700">{r.subject}</td>
              <td className="border border-slate-200 px-2 py-1.5 text-slate-600">{r.teacher}</td>
              <td className="border border-slate-200 px-2 py-1.5 text-center font-bold text-slate-700">{r.n}</td>
            </tr>
          ))}
          <tr className="bg-brand-50">
            <td className="border border-slate-200 px-2 py-1.5 font-extrabold text-brand-700" colSpan={2}>Total</td>
            <td className="border border-slate-200 px-2 py-1.5 text-center font-extrabold text-brand-700">{total}</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}

/** Teacher-wise breakdown: class · subject · periods (+ total workload). */
function TeacherDetails({ teacherId }: { teacherId: string }) {
  const { state } = useApp()
  const wk = teacherWeek(state, teacherId)
  const counts: Record<string, number> = {}
  for (const d of DAYS)
    for (const s of wk[d])
      if (s) counts[`${s.classId}|${s.subjectId}`] = (counts[`${s.classId}|${s.subjectId}`] ?? 0) + 1
  const rows = Object.entries(counts)
    .map(([k, n]) => {
      const [cid, sid] = k.split('|')
      const c = state.classes.find((x) => x.id === cid)
      return { cls: c ? className(c) : '?', subject: findSubject(state, sid)?.name ?? '?', n }
    })
    .sort((a, b) => a.cls.localeCompare(b.cls) || a.subject.localeCompare(b.subject))
  const total = teacherWorkload(state, teacherId)
  const cap = DAYS.length * state.settings.periodsPerDay

  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-3 mt-3 overflow-x-auto no-print">
      <div className="flex items-center justify-between mb-2">
        <p className="font-bold text-slate-800 text-sm">📋 Workload details</p>
        <span className="chip bg-amber-50 text-amber-700">Total: {total} / {cap} periods</span>
      </div>
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="bg-slate-100 text-slate-600 text-xs">
            <th className="border border-slate-200 px-2 py-1.5 text-left">Class</th>
            <th className="border border-slate-200 px-2 py-1.5 text-left">Subject</th>
            <th className="border border-slate-200 px-2 py-1.5 w-20">Periods</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              <td className="border border-slate-200 px-2 py-1.5 font-semibold text-slate-700">{r.cls}</td>
              <td className="border border-slate-200 px-2 py-1.5 text-slate-600">{r.subject}</td>
              <td className="border border-slate-200 px-2 py-1.5 text-center font-bold text-slate-700">{r.n}</td>
            </tr>
          ))}
          <tr className="bg-brand-50">
            <td className="border border-slate-200 px-2 py-1.5 font-extrabold text-brand-700" colSpan={2}>Total workload</td>
            <td className="border border-slate-200 px-2 py-1.5 text-center font-extrabold text-brand-700">{total}</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}
