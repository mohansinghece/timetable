// ===== Core domain types for the KV Ambassa Timetable app =====

export type Stage = 'foundational' | 'preparatory' | 'middle' | 'secondary'

export const DAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'] as const
export type Day = (typeof DAYS)[number]

export const DAY_LABELS: Record<Day, string> = {
  MON: 'Monday',
  TUE: 'Tuesday',
  WED: 'Wednesday',
  THU: 'Thursday',
  FRI: 'Friday',
  SAT: 'Saturday',
}

/** A teaching post / designation, e.g. PRT, TGT, PGT. */
export interface Post {
  id: string
  name: string
  /** Short code shown on chips, e.g. "PRT". */
  code: string
}

/** A subject / learning area. */
export interface Subject {
  id: string
  name: string
  /** Acronym shown inside timetable cells, e.g. "TWAU". */
  acronym: string
  /** Optional cell colour (hex) used in timetable views. */
  color?: string
}

/** A teacher record. */
export interface Teacher {
  id: string
  name: string
  /** Short acronym shown inside timetable cells next to the subject. */
  acronym: string
  postId: string
}

/** A class + section, e.g. "VI A". */
export interface SchoolClass {
  id: string
  /** Roman grade label, e.g. "VI". */
  grade: string
  section: string
  stage: Stage
  classTeacherId?: string
  coClassTeacherId?: string
  /** Teacher who takes the first period each day (defaults to class teacher). */
  firstPeriodTeacherId?: string
}

/** One subject requirement inside a class (subject + periods/week + block flag). */
export interface ClassSubjectItem {
  subjectId: string
  periodsPerWeek: number
  /** When true, auto-fill places it as two consecutive (block) periods. */
  block: boolean
  /** Main subject — must appear every working day (e.g. Hindi/English/Maths). */
  main?: boolean
  /** Teacher who teaches this subject in this class (single-teacher mode). */
  teacherId?: string
  /** Locked teacher: scheduled first (teacher can't be substituted). */
  lockTeacher?: boolean
  /** When true, the subject is split across multiple teachers (see `teachers`). */
  multiTeacher?: boolean
  /** Per-teacher period split when multiTeacher is on. */
  teachers?: { teacherId: string; periods: number }[]
  /** Optional pinned day for this subject (used for CLA block placement). */
  fixedDay?: Day
  /** Optional pinned start period (0-based) for this subject. */
  fixedStartPeriod?: number
}

/** Per-class subject configuration. */
export interface ClassSubjectConfig {
  classId: string
  items: ClassSubjectItem[]
}

/** A single timetable cell. */
export interface Slot {
  subjectId: string
  teacherId: string
}

/** Timetable for one class: grid[day][periodIndex] (0-based period). */
export type ClassGrid = Record<Day, (Slot | null)[]>

export interface Timetable {
  classId: string
  grid: ClassGrid
}

export interface PeriodTiming {
  /** "09:00" */
  start: string
  /** "09:40" */
  end: string
  /** Marks the recess/lunch break that follows this period index. */
  isBreak?: boolean
  /** Break that occurs right after this period (for display). */
  breakAfter?: { label: string; minutes: number; end: string }
}

/** A break/recess after a given period. */
export interface BreakDef {
  afterPeriod: number
  minutes: number
  label: string
}

export interface Settings {
  schoolName: string
  periodsPerDay: number
  periodMinutes: number
  recessMinutes: number
  /** Period index (1-based) after which recess occurs. */
  recessAfterPeriod: number
  dayStart: string
  adminPassword: string
  /** Configurable breaks (replaces the single recess when present). */
  breaks?: BreakDef[]
}

// ===== Arrangement (substitution) module =====

export interface ArrangementAssignment {
  /** Key: `${absentTeacherId}|${period}` */
  classId: string
  subjectAcr: string
  period: number
  coverTeacherId?: string
  remarks?: string
}

export interface ArrangementDay {
  date: string // yyyy-mm-dd
  absentTeacherIds: string[]
  suspendedClassIds: string[]
  /** Map keyed by `${absentTeacherId}|${period}` -> assignment. */
  assignments: Record<string, { coverTeacherId?: string; remarks?: string }>
}

// ===== Root persisted state =====

export interface AppState {
  settings: Settings
  posts: Post[]
  subjects: Subject[]
  teachers: Teacher[]
  classes: SchoolClass[]
  classSubjects: ClassSubjectConfig[]
  timings: PeriodTiming[]
  timetables: Timetable[]
  arrangements: ArrangementDay[]
  /** Common-teacher busy slots (other-section) kept until reset.
   *  Map teacherId -> array of `${Day}|${period}`. */
  commonBusy?: Record<string, string[]>
}
